
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Bell, Search, Menu, HelpCircle, Command, X } from 'lucide-react';

interface HeaderProps {
  toggleSidebar: () => void;
}

export const Header: React.FC<HeaderProps> = ({ toggleSidebar }) => {
  const location = useLocation();
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const getPageTitle = (path: string) => {
    switch (path) {
      case '/dashboard': return 'Dashboard';
      case '/agent': return 'Unified AI Agent';
      case '/campaigns': return 'Campaigns';
      case '/email-builder': return 'Email Builder';
      case '/popups': return 'Smart Popups';
      case '/social': return 'Social Automator';
      case '/commerce': return 'Commerce Hub';
      case '/inbox': return 'Unified Inbox';
      case '/customers': return 'CRM & Customers';
      case '/ai-planner': return 'AI Strategy Planner';
      default: return 'Overview';
    }
  };

  return (
    <header className="h-16 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 flex items-center justify-between px-4 sticky top-0 z-10">
      
      {/* Mobile Search Overlay */}
      {isSearchOpen && (
        <div className="absolute inset-0 bg-slate-900 z-20 flex items-center px-4 lg:hidden animate-in fade-in duration-200">
          <Search className="w-5 h-5 text-slate-500 mr-3" />
          <input 
            type="text" 
            placeholder="Search..." 
            className="flex-1 bg-transparent border-none text-white focus:ring-0 outline-none placeholder-slate-500 h-full"
            autoFocus
          />
          <button onClick={() => setIsSearchOpen(false)} className="p-2 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      <div className="flex items-center flex-1 gap-4">
        <button onClick={toggleSidebar} className="p-2 text-slate-400 hover:text-white md:hidden">
          <Menu className="w-6 h-6" />
        </button>
        
        {/* Page Title (Mobile/Desktop) */}
        <h2 className={`text-lg font-semibold text-white hidden md:block min-w-max ${isSearchOpen ? 'lg:block' : ''}`}>
          {getPageTitle(location.pathname)}
        </h2>

        {/* Search Bar (Desktop) */}
        <div className="relative ml-4 max-w-md w-full hidden lg:block group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-brand-500 transition-colors" />
          <input 
            type="text" 
            placeholder="Search orders, customers, or ask AI..." 
            className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-sm rounded-full pl-10 pr-12 py-2 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 placeholder-slate-500 transition-all"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
             <span className="text-[10px] text-slate-500 border border-slate-700 px-1.5 py-0.5 rounded bg-slate-900"><Command className="w-3 h-3 inline"/> K</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        
        {/* Mobile Search Trigger */}
        <button 
            onClick={() => setIsSearchOpen(true)} 
            className="lg:hidden p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-all"
        >
            <Search className="w-5 h-5" />
        </button>

        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-brand-500/10 rounded-full border border-brand-500/20">
            <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse"></span>
            <span className="text-xs font-medium text-brand-400">System Operational</span>
        </div>

        <div className="h-8 w-px bg-slate-800 mx-2 hidden md:block"></div>

        <button className="relative p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-all">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-slate-900"></span>
        </button>
        <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-all">
          <HelpCircle className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};

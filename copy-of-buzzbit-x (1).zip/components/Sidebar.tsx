
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Megaphone, 
  Users, 
  MessageSquare, 
  BrainCircuit, 
  Settings, 
  Zap,
  ShoppingBag,
  Share2,
  Maximize,
  PenTool,
  Bot,
  LogOut,
  Link2,
  LayoutGrid
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  toggle: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggle }) => {
  const location = useLocation();
  
  const menuItems = [
    // Core
    { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
    { icon: Bot, label: 'Unified Agent', path: '/agent' },
    
    // Growth
    { icon: Megaphone, label: 'Campaigns', path: '/campaigns' },
    { icon: PenTool, label: 'Email Builder', path: '/email-builder' },
    { icon: Share2, label: 'Social Automator', path: '/social' },
    { icon: Maximize, label: 'Smart Popups', path: '/popups' },
    
    // Management (Consolidated)
    { icon: LayoutGrid, label: 'Business Hub', path: '/business' },
    { icon: BrainCircuit, label: 'AI Planner', path: '/ai-planner' },
    
    // Platform
    { icon: Link2, label: 'Integrations', path: '/integrations' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      <div 
        className={`fixed inset-0 bg-black/50 z-40 md:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100 visible' : 'opacity-0 invisible pointer-events-none'}`}
        onClick={toggle}
      />
      <div 
        className={`fixed md:static inset-y-0 left-0 z-50 h-full bg-slate-900 border-r border-slate-800 flex flex-col transition-all duration-300 ${isOpen ? 'w-64 translate-x-0' : '-translate-x-full w-64 md:translate-x-0 md:w-20'}`}
      >
        <div className="h-16 flex items-center px-6 border-b border-slate-800 flex-shrink-0">
          <Link to="/landing" className="flex items-center hover:opacity-80 transition-opacity overflow-hidden">
              <Zap className="w-8 h-8 text-brand-500 mr-3 flex-shrink-0" />
              <span className={`font-bold text-xl tracking-tight text-white transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 md:hidden'}`}>
                BuzzBit<span className="text-brand-500">X</span>
              </span>
          </Link>
        </div>

        <div className="flex-1 py-6 flex flex-col gap-1 px-3 overflow-y-auto overflow-x-hidden custom-scrollbar">
          {menuItems.map((item, index) => (
            <React.Fragment key={item.path}>
              {isOpen && (index === 2 || index === 6 || index === 8) && (
                <div className="px-3 py-2 text-xs font-bold text-slate-600 uppercase tracking-wider mt-2 mb-1">
                  {index === 2 ? 'Growth' : index === 6 ? 'Operations' : 'Platform'}
                </div>
              )}
              <Link
                to={item.path}
                className={`flex items-center px-3 py-2.5 rounded-lg transition-colors group whitespace-nowrap ${isActive(item.path) ? 'bg-brand-500/10 text-brand-400' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
                title={!isOpen ? item.label : ''}
              >
                <item.icon className={`w-5 h-5 flex-shrink-0 ${isOpen ? 'mr-3' : 'mx-auto'}`} />
                <span className={`font-medium text-sm transition-opacity duration-200 ${isOpen ? 'opacity-100' : 'opacity-0 w-0 hidden md:block'}`}>{item.label}</span>
              </Link>
            </React.Fragment>
          ))}
        </div>

        <div className="p-4 border-t border-slate-800 bg-slate-900 flex-shrink-0">
           <div className="flex items-center px-2 py-2 cursor-pointer hover:bg-slate-800 rounded-lg transition-colors mb-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-brand-400 to-blue-500 flex items-center justify-center text-xs font-bold text-white shadow-lg flex-shrink-0">JD</div>
              <div className={`ml-3 overflow-hidden transition-opacity duration-200 ${isOpen ? 'opacity-100' : 'opacity-0 w-0 hidden'}`}>
                <p className="text-sm font-medium text-white truncate">John Doe</p>
                <p className="text-xs text-slate-500 truncate">Admin Workspace</p>
              </div>
           </div>
           <Link to="/auth" className="flex items-center px-2 py-1 text-slate-500 hover:text-red-400 transition-colors whitespace-nowrap">
              <LogOut className={`w-4 h-4 flex-shrink-0 ${isOpen ? 'mr-3' : 'mx-auto'}`} />
              <span className={`text-xs font-medium transition-opacity duration-200 ${isOpen ? 'opacity-100' : 'opacity-0 w-0 hidden'}`}>Sign Out</span>
           </Link>
        </div>
      </div>
    </>
  );
};

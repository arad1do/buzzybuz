import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { KPI } from '../types';

export const StatsCard: React.FC<{ kpi: KPI; icon: React.ElementType }> = ({ kpi, icon: Icon }) => {
  const isPositive = kpi.trend === 'up';
  
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-all duration-300 shadow-lg relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110">
        <Icon className="w-16 h-16 text-brand-500" />
      </div>
      
      <div className="flex items-start justify-between mb-4">
        <div className="p-2 bg-slate-800 rounded-lg text-brand-400">
          <Icon className="w-6 h-6" />
        </div>
        <div className={`flex items-center text-sm font-medium ${isPositive ? 'text-emerald-400' : 'text-red-400'} bg-slate-950/50 px-2 py-1 rounded-full`}>
          {isPositive ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
          {Math.abs(kpi.change)}%
        </div>
      </div>
      
      <div>
        <h3 className="text-slate-400 text-sm font-medium mb-1">{kpi.label}</h3>
        <p className="text-2xl font-bold text-white tracking-tight">{kpi.value}</p>
      </div>
    </div>
  );
};

import React from 'react';

export interface KPI {
  label: string;
  value: string;
  change: number;
  trend: 'up' | 'down' | 'neutral';
}

export interface Campaign {
  id: string;
  name: string;
  status: 'active' | 'draft' | 'completed' | 'scheduled';
  channel: 'email' | 'sms' | 'whatsapp';
  sent: number;
  openRate: number;
  clickRate: number;
  revenue: number;
  createdAt: string;
}

export type CustomerStatus = 'active' | 'churned' | 'lead';
export type LeadStage = 'new' | 'contacted' | 'qualified' | 'proposal' | 'won' | 'lost';

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone?: string;
  type: 'customer' | 'lead';
  status: CustomerStatus;
  leadStage?: LeadStage;
  ltv: number;
  segment: string;
  lastActive: string;
  riskScore: number; // 0-100, higher is worse
  company?: string;
  tags: string[];
  nextBestAction?: string;
}

export interface Segment {
  id: string;
  name: string;
  description: string;
  criteria: string;
  count: number;
  icon: 'users' | 'star' | 'alert' | 'zap';
  avgLtv: number;
  tags: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface InboxThread {
  id: string;
  customerName: string;
  lastMessage: string;
  platform: 'whatsapp' | 'sms' | 'email' | 'chat';
  timestamp: string;
  unread: boolean;
  tags: string[];
}

export interface ProductVariant {
  id: string;
  name: string; // e.g. "Red / L"
  sku: string;
  price: number;
  stock: number;
}

export interface Product {
  id: string;
  name: string;
  sku: string; // Base SKU
  price: number; // Base price
  stock: number; // Total stock
  variants: ProductVariant[];
  category: string;
  image?: string;
  status: 'active' | 'draft' | 'archived';
}

export interface Order {
  id: string;
  customer: string;
  email: string;
  total: number;
  status: 'pending' | 'paid' | 'shipped' | 'delivered' | 'returned';
  paymentStatus: 'paid' | 'unpaid' | 'refunded';
  date: string;
  items: number;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  category: string;
  amount: number;
  description: string;
  date: string;
  status: 'cleared' | 'pending';
}

export type SocialPlatform = 'instagram' | 'twitter' | 'linkedin' | 'tiktok' | 'youtube';

export interface SocialPost {
  id: string;
  platform: SocialPlatform;
  content: string;
  scheduledTime: string; // ISO string
  status: 'draft' | 'scheduled' | 'published';
  mediaUrl?: string;
  analytics?: {
    likes: number;
    shares: number;
    comments: number;
    reach: number;
  };
}

export interface Popup {
  id: string;
  name: string;
  type: 'exit-intent' | 'scroll' | 'timer';
  conversionRate: number;
  status: 'active' | 'paused';
  views: number;
}

// --- Flow & Email Builder Types ---

export type NodeType = 
  | 'trigger' 
  | 'action_email' 
  | 'action_sms' 
  | 'delay' 
  | 'condition' 
  | 'split' // Legacy alias
  | 'split_random' // A/B Testing
  | 'action_tag' // CRM Tagging
  | 'action_notification'; // Team Alert

export interface FlowNode {
  id: string;
  type: NodeType;
  title: string;
  description?: string;
  data?: any;
  children?: FlowNode[]; // Linear next steps
  branches?: {
    true: FlowNode[];
    false: FlowNode[];
  }; // For conditions
}

export interface EmailElement {
  id: string;
  type: 'text' | 'image' | 'button' | 'spacer' | 'divider';
  content: string;
  style?: React.CSSProperties;
  src?: string; // For images
  alt?: string;
  link?: string;
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  previewText: string;
  elements: EmailElement[];
  branding: {
    primaryColor: string;
    backgroundColor: string;
    logoUrl: string;
  }
}

// --- WhatsApp Agent Types ---

export type IntentCategory = 'sales' | 'service' | 'booking' | 'info' | 'engagement';

export interface Intent {
  id: string;
  name: string;
  category: IntentCategory;
  description: string;
  triggers: string[];
  responseTemplate: string;
  isEnabled: boolean;
  automationRate: number;
}

export type BrandTonePreset = 'professional' | 'friendly' | 'energetic' | 'luxury' | 'minimalist';

export interface BrandToneConfig {
  preset: BrandTonePreset;
  customInstructions: string;
  emojiUsage: 'none' | 'minimal' | 'moderate' | 'frequent';
}

export interface FollowUpRule {
  id: string;
  type: 'abandoned_cart' | 'post_purchase' | 'win_back' | 'review_request';
  name: string;
  delay: number; // minutes
  isEnabled: boolean;
  template: string;
}

// --- Settings & Integration Types ---

export interface Integration {
  id: string;
  name: string;
  category: 'ecommerce' | 'social' | 'marketing' | 'payment' | 'automation' | 'productivity' | 'logistics';
  status: 'connected' | 'disconnected';
  icon: string; // URL or Lucide icon name reference
  lastSync?: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: 'admin' | 'editor' | 'viewer';
  email: string;
  avatar?: string;
  status: 'active' | 'invited';
}

export interface Discount {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  status: 'active' | 'expired' | 'scheduled';
  usageCount: number;
  usageLimit: number;
  expiresAt?: string;
}

// --- Autonomous Agent Types ---

export interface AgentStep {
  id: string;
  label: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  logs: string[];
  tool: 'browser' | 'analysis' | 'create' | 'api';
}

export interface AgentArtifact {
  id: string;
  type: 'email' | 'image' | 'code' | 'data' | 'document';
  title: string;
  content: string;
  previewUrl?: string;
}

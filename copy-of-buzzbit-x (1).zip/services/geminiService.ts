
import { GoogleGenAI } from "@google/genai";
import { AgentStep } from '../types';

// Initialize Gemini client safely
const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API Key for Gemini is missing. AI features will use mock responses or fail.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generateMarketingCopy = async (
  topic: string,
  channel: 'email' | 'sms' | 'whatsapp',
  tone: string
): Promise<string> => {
  const client = getClient();
  if (!client) return "Simulation: API Key missing. Please configure API_KEY.";

  try {
    const prompt = `You are an expert marketing copywriter for BuzzBit X.
    Write a high-converting ${channel} message about "${topic}".
    Tone: ${tone}.
    Keep it concise and engaging.
    For SMS/WhatsApp, keep it under 160 characters if possible, or very short.
    For Email, provide a Subject and Body.`;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Failed to generate content.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Error generating content. Please try again.";
  }
};

export const generateSocialContent = async (
  topic: string, 
  platform: string, 
  tone: string
): Promise<string> => {
  const client = getClient();
  if (!client) return "Simulation: AI content generation unavailable without API Key.";

  try {
    const prompt = `Write a social media post for ${platform} about "${topic}".
    Tone: ${tone}.
    Include relevant hashtags (3-5).
    If it's Twitter/X, keep it under 280 characters.
    If it's LinkedIn, make it professional yet engaging.
    If it's Instagram, make it visual and emoji-friendly.
    Return ONLY the post content.`;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    return response.text || "Content generation failed.";
  } catch (error) {
    console.error("Gemini Social Gen Error:", error);
    return "Error generating social content.";
  }
};

export const analyzeDataInsights = async (dataContext: string): Promise<string> => {
  const client = getClient();
  if (!client) return "Simulation: Configure API Key to see real AI insights.";

  try {
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze this e-commerce data context and provide 3 actionable strategic recommendations in a JSON array format (just the array text). Context: ${dataContext}`,
    });
    return response.text || "[]";
  } catch (error) {
    console.error("Gemini API Insight Error:", error);
    return "[]";
  }
};

export const chatWithAI = async (message: string, history: {role: 'user' | 'model', parts: {text: string}[]}[]): Promise<string> => {
    const client = getClient();
    if (!client) return "I am an AI simulation. Please provide an API Key to activate my full brain.";

    try {
        const chat = client.chats.create({
            model: 'gemini-2.5-flash',
            history: history,
        });
        
        const result = await chat.sendMessage(message);
        return result.text || "";
    } catch (e) {
        console.error(e);
        return "I encountered an error processing your request.";
    }
}

export const optimizeEmailContent = async (currentContent: string, type: 'subject' | 'body' | 'cta'): Promise<string> => {
  const client = getClient();
  if (!client) return "AI Optimization Unavailable";

  try {
    const prompt = `Optimize this email ${type} for higher conversion rates. Keep the brand voice professional yet urgent.
    Current content: "${currentContent}"
    Return ONLY the optimized text, nothing else.`;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || currentContent;
  } catch (error) {
    console.error("Optimization Error:", error);
    return currentContent;
  }
};

export const generateNextBestAction = async (customerName: string, recentHistory: string): Promise<string> => {
  const client = getClient();
  if (!client) return "Review account health";

  try {
    const prompt = `Given customer ${customerName} with history: ${recentHistory}.
    What is the single most profitable next action for the CRM agent?
    Examples: "Send discount", "Call for renewal", "Ignore".
    Keep it under 5 words.`;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "Check activity";
  } catch (error) {
    return "Analyze pattern";
  }
};

export const optimizeIntent = async (
  trigger: string,
  responseTemplate: string
): Promise<{ triggers: string[]; response: string }> => {
  const client = getClient();
  if (!client) {
    return { 
      triggers: [trigger, "simulated trigger 1", "simulated trigger 2"], 
      response: `(AI Optimized) ${responseTemplate}` 
    };
  }

  try {
    const prompt = `
      Act as a Conversation Design Expert.
      Optimize the following Intent for a Customer Service AI Agent.
      
      Current Triggers: "${trigger}"
      Current Response: "${responseTemplate}"
      
      Task:
      1. Expand the triggers to include 3-5 variations (synonyms, different phrasings).
      2. Rewrite the response to be more empathetic, helpful, and concise.
      
      Output strictly in JSON format:
      {
        "triggers": ["trigger 1", "trigger 2", ...],
        "response": "The optimized response text"
      }
    `;

    const result = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const text = result.text || "";
    const jsonStr = text.replace(/```json|```/g, '').trim();
    return JSON.parse(jsonStr);

  } catch (error) {
    console.error("Optimize Intent Error:", error);
    return { triggers: [trigger], response: responseTemplate };
  }
};

export const simulateUnifiedAgent = async (
  message: string, 
  tone: string, 
  platform: string,
  context: string = ""
): Promise<{ text: string; intent: string; confidence: number }> => {
  const client = getClient();
  if (!client) return { text: "Agent simulation requires API Key.", intent: 'system_error', confidence: 0 };

  try {
    const prompt = `Act as a highly intelligent AI Agent for an e-commerce store named BuzzBit X.
    
    Configuration:
    - Platform: ${platform} (Adjust formatting accordingly, e.g., short for Twitter, visual for IG)
    - Tone: ${tone}
    - Context: ${context}
    
    Customer Message: "${message}"
    
    Task:
    1. Detect the intent.
    2. Generate a response strictly matching the Tone and Platform constraints.
    3. Estimate confidence score (0.0 to 1.0).
    
    Output JSON ONLY in this format:
    {
      "text": "The response message",
      "intent": "detected_intent",
      "confidence": 0.95
    }`;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const raw = response.text || "";
    const jsonStr = raw.replace(/```json|```/g, '').trim();
    
    try {
      return JSON.parse(jsonStr);
    } catch (e) {
      return { text: raw, intent: 'unknown', confidence: 0.5 };
    }

  } catch (error) {
    console.error("Agent Simulation Error:", error);
    return { text: "I'm having trouble connecting to my brain right now.", intent: 'system_error', confidence: 0 };
  }
};

export const simulateWhatsAppAgent = async (
  message: string, 
  tone: string, 
  context: string = ""
): Promise<{ text: string; intent: string; confidence: number }> => {
  return simulateUnifiedAgent(message, tone, 'WhatsApp', context);
};

export const queryCopilot = async (
  userMessage: string, 
  pageContext: string
): Promise<string> => {
    const client = getClient();
    if (!client) return "I am the BuzzBit Co-Pilot. Please configure your API Key to enable my full capabilities.";

    try {
        const prompt = `You are BuzzBit X Co-Pilot, an intelligent assistant embedded in an e-commerce automation platform.
        
        Current Page Context: ${pageContext}
        
        User Question: "${userMessage}"
        
        Provide a helpful, concise response. 
        If the user asks to do something (e.g., "create campaign"), explain how to do it on the platform.
        If they ask for insights, simulate a data analysis based on general e-commerce knowledge.`;

        const response = await client.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        
        return response.text || "I'm here to help, but I couldn't process that request.";
    } catch (e) {
        console.error(e);
        return "I'm having trouble connecting to the mainframe. Please try again.";
    }
};

export const generateAgentPlan = async (goal: string): Promise<AgentStep[]> => {
  const client = getClient();
  if (!client) {
    // Mock plan for demo without key
    return [
      { id: '1', label: 'Analyze current store performance', status: 'pending', logs: [], tool: 'analysis' },
      { id: '2', label: 'Identify target audience segments', status: 'pending', logs: [], tool: 'analysis' },
      { id: '3', label: 'Draft email campaign content', status: 'pending', logs: [], tool: 'create' },
      { id: '4', label: 'Configure automation triggers', status: 'pending', logs: [], tool: 'api' },
    ];
  }

  try {
    const prompt = `
      You are an Autonomous E-commerce Agent Planner.
      User Goal: "${goal}"
      
      Break this goal down into 4-6 executable steps.
      Each step should simulate a real action like "Analyze data", "Draft email", "Design image", "Configure setting".
      
      Output strictly JSON array:
      [
        { "id": "1", "label": "Step description", "tool": "analysis|create|browser|api" },
        ...
      ]
    `;

    const result = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const text = result.text || "";
    const jsonStr = text.replace(/```json|```/g, '').trim();
    const steps = JSON.parse(jsonStr);
    return steps.map((s: any) => ({ ...s, status: 'pending', logs: [] }));
  } catch (e) {
    console.error("Planning Error:", e);
    return [
      { id: '1', label: 'Analyze request', status: 'pending', logs: [], tool: 'analysis' },
      { id: '2', label: 'Execute primary task', status: 'pending', logs: [], tool: 'create' },
      { id: '3', label: 'Finalize output', status: 'pending', logs: [], tool: 'api' }
    ];
  }
};

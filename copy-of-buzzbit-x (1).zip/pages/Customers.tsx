
import React, { useState } from 'react';
import { Search, Filter, Download, MoreHorizontal, UserPlus, Users, Target, Briefcase, Zap, ArrowRight, Star, AlertTriangle } from 'lucide-react';
import { Customer, Segment, LeadStage } from '../types';

const MOCK_CUSTOMERS: Customer[] = [
  { id: '1', name: 'Alice Freeman', email: 'alice.f@example.com', phone: '+1 555-0101', type: 'customer', status: 'active', ltv: 1240.50, segment: 'VIP', lastActive: '2 mins ago', riskScore: 5, tags: ['High Value', 'Frequent Buyer'], nextBestAction: 'Send VIP Early Access' },
  { id: '2', name: 'Bob Smith', email: 'bob.smith@example.com', type: 'customer', status: 'active', ltv: 450.00, segment: 'Loyal', lastActive: '4 hours ago', riskScore: 15, tags: ['Apparel'], nextBestAction: 'Recommend matching items' },
  { id: '3', name: 'TechCorp Inc.', email: 'procurement@techcorp.com', type: 'lead', status: 'lead', leadStage: 'proposal', ltv: 0, segment: 'B2B Lead', lastActive: '1 day ago', riskScore: 0, company: 'TechCorp', tags: ['B2B', 'Bulk'], nextBestAction: 'Follow up on quote' },
  { id: '4', name: 'Sarah Jones', email: 's.jones@start.up', type: 'lead', status: 'lead', leadStage: 'new', ltv: 0, segment: 'Inbound', lastActive: 'Just now', riskScore: 0, tags: ['Web Form'], nextBestAction: 'Initial outreach' },
];

const MOCK_SEGMENTS: Segment[] = [
  { id: 's1', name: 'VIP Whales', description: 'LTV > $1000 & Active last 30 days', count: 142, icon: 'star', criteria: 'ltv > 1000 AND last_active < 30d', avgLtv: 2450, tags: ['High Priority'] },
  { id: 's2', name: 'Churn Risk', description: 'Risk Score > 70 & No purchase 60 days', count: 85, icon: 'alert', criteria: 'risk > 70 AND last_order > 60d', avgLtv: 450, tags: ['Win-back'] },
  { id: 's3', name: 'New Signups', description: 'Joined last 7 days, 0 purchases', count: 320, icon: 'users', criteria: 'created < 7d AND orders = 0', avgLtv: 0, tags: ['Onboarding'] },
];

export const Customers: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'leads' | 'segments'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Filter helpers
  const customers = MOCK_CUSTOMERS.filter(c => c.type === 'customer');
  const leads = MOCK_CUSTOMERS.filter(c => c.type === 'lead');
  
  const getLeadStageColor = (stage?: LeadStage) => {
    switch(stage) {
      case 'new': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'contacted': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'qualified': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'proposal': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'won': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      default: return 'bg-slate-800 text-slate-400';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            {activeTab === 'all' && <Users className="w-6 h-6 text-brand-500" />}
            {activeTab === 'leads' && <Target className="w-6 h-6 text-brand-500" />}
            {activeTab === 'segments' && <Briefcase className="w-6 h-6 text-brand-500" />}
            CRM & Customers
          </h1>
          <p className="text-slate-400">Manage relationships, pipeline, and audiences.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
            <button onClick={() => setActiveTab('all')} className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'all' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>Contacts</button>
            <button onClick={() => setActiveTab('leads')} className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'leads' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>Lead Pipeline</button>
            <button onClick={() => setActiveTab('segments')} className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'segments' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>Segments</button>
          </div>
          <button className="bg-brand-600 hover:bg-brand-500 text-white px-4 py-2 rounded-lg transition-all flex items-center gap-2 shadow-lg shadow-brand-500/20">
            <UserPlus className="w-4 h-4" /> New Contact
          </button>
        </div>
      </div>

      {/* --- ALL CONTACTS TAB --- */}
      {activeTab === 'all' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
          <div className="p-4 border-b border-slate-800 flex gap-4">
             <div className="relative flex-1 max-w-md">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
               <input 
                 type="text" 
                 value={searchTerm}
                 onChange={(e) => setSearchTerm(e.target.value)}
                 placeholder="Search contacts..." 
                 className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-slate-200 focus:border-brand-500 outline-none"
               />
             </div>
             <button className="flex items-center gap-2 px-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors">
               <Filter className="w-4 h-4" /> Filters
             </button>
             <button className="flex items-center gap-2 px-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors">
               <Download className="w-4 h-4" /> Export
             </button>
          </div>

          <table className="w-full text-left text-sm text-slate-400">
            <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium">
                <tr>
                <th className="px-6 py-4">Customer</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">LTV</th>
                <th className="px-6 py-4">Risk Score</th>
                <th className="px-6 py-4">AI Insight</th>
                <th className="px-6 py-4 text-right">Action</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
                {customers.map((customer) => (
                <tr key={customer.id} className="hover:bg-slate-800/30 transition-colors group cursor-pointer">
                    <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-700 to-slate-600 flex items-center justify-center text-white font-bold text-xs">
                                {customer.name.charAt(0)}
                            </div>
                            <div>
                                <p className="font-medium text-white">{customer.name}</p>
                                <p className="text-xs text-slate-500">{customer.email}</p>
                            </div>
                        </div>
                    </td>
                    <td className="px-6 py-4">
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 capitalize">
                            {customer.segment}
                        </span>
                    </td>
                    <td className="px-6 py-4 text-right font-medium text-white">
                        ${customer.ltv.toLocaleString()}
                    </td>
                    <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                            <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                <div className={`h-full ${customer.riskScore > 50 ? 'bg-red-500' : 'bg-emerald-500'}`} style={{ width: `${customer.riskScore}%` }}></div>
                            </div>
                            <span className="text-xs">{customer.riskScore}%</span>
                        </div>
                    </td>
                    <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-brand-400 text-xs font-medium">
                            <Zap className="w-3 h-3" />
                            {customer.nextBestAction}
                        </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                        <button className="p-1 hover:text-white text-slate-500"><MoreHorizontal className="w-4 h-4" /></button>
                    </td>
                </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}

      {/* --- LEAD PIPELINE TAB --- */}
      {activeTab === 'leads' && (
        <div className="h-[calc(100vh-220px)] overflow-x-auto pb-4">
            <div className="flex gap-4 min-w-max h-full">
                {['new', 'contacted', 'qualified', 'proposal', 'won'].map((stage) => (
                    <div key={stage} className="w-72 flex flex-col bg-slate-900/50 border border-slate-800 rounded-xl h-full">
                        <div className="p-3 border-b border-slate-800 flex justify-between items-center sticky top-0 bg-slate-900 rounded-t-xl z-10">
                            <h3 className="font-bold text-white capitalize flex items-center gap-2">
                                <div className={`w-2 h-2 rounded-full ${stage === 'won' ? 'bg-emerald-500' : 'bg-brand-500'}`}></div>
                                {stage}
                            </h3>
                            <span className="bg-slate-800 text-slate-400 px-2 py-0.5 rounded text-xs">
                                {leads.filter(l => l.leadStage === stage).length}
                            </span>
                        </div>
                        <div className="flex-1 p-3 space-y-3 overflow-y-auto">
                             {leads.filter(l => l.leadStage === stage).map(lead => (
                                 <div key={lead.id} className="bg-slate-800 border border-slate-700 p-3 rounded-lg hover:border-brand-500 cursor-grab active:cursor-grabbing shadow-sm transition-all group">
                                     <div className="flex justify-between items-start mb-2">
                                         <span className="text-xs text-slate-400 font-mono">{lead.company || 'Individual'}</span>
                                         <button className="text-slate-600 group-hover:text-white transition-colors"><MoreHorizontal className="w-3 h-3" /></button>
                                     </div>
                                     <h4 className="font-bold text-white text-sm mb-1">{lead.name}</h4>
                                     <p className="text-xs text-slate-500 mb-3">{lead.email}</p>
                                     
                                     <div className="flex flex-wrap gap-1 mb-3">
                                         {lead.tags.map(tag => (
                                             <span key={tag} className="px-1.5 py-0.5 bg-slate-900 rounded text-[10px] text-slate-300 border border-slate-700">{tag}</span>
                                         ))}
                                     </div>

                                     <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between">
                                         <div className="flex items-center gap-1 text-[10px] text-brand-400">
                                             <Zap className="w-3 h-3" />
                                             {lead.nextBestAction}
                                         </div>
                                         <div className="w-6 h-6 rounded-full bg-slate-700 flex items-center justify-center text-[10px] text-white">
                                            {lead.name.charAt(0)}
                                         </div>
                                     </div>
                                 </div>
                             ))}
                             <button className="w-full py-2 border border-dashed border-slate-700 rounded-lg text-slate-500 text-sm hover:bg-slate-800 hover:text-white transition-colors">
                                 + Add Lead
                             </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      )}

      {/* --- SEGMENTS TAB --- */}
      {activeTab === 'segments' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {MOCK_SEGMENTS.map(segment => (
                <div key={segment.id} className="bg-slate-900 border border-slate-800 rounded-xl p-6 hover:border-slate-600 transition-all group">
                    <div className="flex justify-between items-start mb-4">
                        <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-brand-400 group-hover:bg-brand-500/20 transition-colors">
                            {segment.icon === 'star' && <Star className="w-5 h-5" />}
                            {segment.icon === 'alert' && <AlertTriangle className="w-5 h-5 text-red-400" />}
                            {segment.icon === 'users' && <Users className="w-5 h-5" />}
                        </div>
                        <button className="text-slate-500 hover:text-white"><MoreHorizontal className="w-5 h-5" /></button>
                    </div>
                    
                    <h3 className="text-lg font-bold text-white mb-1">{segment.name}</h3>
                    <p className="text-sm text-slate-400 mb-4 h-10">{segment.description}</p>
                    
                    <div className="bg-slate-950 rounded-lg p-3 mb-4 font-mono text-xs text-slate-500 border border-slate-800 truncate">
                        {segment.criteria}
                    </div>

                    <div className="flex items-center justify-between text-sm border-t border-slate-800 pt-4">
                        <div>
                            <p className="text-slate-500 text-xs">Contacts</p>
                            <p className="font-bold text-white">{segment.count}</p>
                        </div>
                        <div className="text-right">
                            <p className="text-slate-500 text-xs">Avg LTV</p>
                            <p className="font-bold text-emerald-400">${segment.avgLtv}</p>
                        </div>
                    </div>
                </div>
            ))}
            
            {/* Create Segment */}
            <div className="bg-slate-900/50 border-2 border-dashed border-slate-800 rounded-xl flex flex-col items-center justify-center p-8 text-slate-500 hover:text-brand-400 hover:border-brand-500/50 hover:bg-slate-900 transition-all cursor-pointer group min-h-[280px]">
                <div className="w-14 h-14 rounded-full bg-slate-800 group-hover:bg-brand-500/20 flex items-center justify-center mb-4 transition-colors">
                    <Zap className="w-7 h-7" />
                </div>
                <h3 className="font-bold">AI Segment Generator</h3>
                <p className="text-xs mt-2 text-center opacity-70 max-w-[200px]">"Create a segment for high-value customers who haven't purchased in 60 days"</p>
            </div>
        </div>
      )}
    </div>
  );
};

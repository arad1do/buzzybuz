
import React from 'react';
import { Link } from 'react-router-dom';
import { Zap, Check, ArrowRight, BarChart3, Users, Globe, Shield } from 'lucide-react';

export const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans selection:bg-brand-500/30">
      {/* Nav */}
      <nav className="container mx-auto px-6 py-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Zap className="w-8 h-8 text-brand-500" />
          <span className="text-2xl font-bold">BuzzBit<span className="text-brand-500">X</span></span>
        </div>
        <div className="flex items-center gap-6">
          <Link to="/auth" className="text-slate-300 hover:text-white font-medium hidden md:block">Sign In</Link>
          <Link 
            to="/auth" 
            className="bg-brand-600 hover:bg-brand-500 text-white px-6 py-2.5 rounded-full font-medium transition-all shadow-[0_0_20px_rgba(20,184,166,0.3)] hover:shadow-[0_0_30px_rgba(20,184,166,0.5)]"
          >
            Get Started
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <header className="container mx-auto px-6 pt-20 pb-32 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900 border border-slate-800 text-brand-400 text-sm font-medium mb-8 animate-fade-in-up">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
          </span>
          Now with Gemini 2.5 AI Models
        </div>
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-8 bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-400 max-w-4xl mx-auto">
          Automate your entire e-commerce empire.
        </h1>
        <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed">
          One platform to manage marketing, support, analytics, and growth. 
          Replace 10+ tools with the world's most intelligent AI engine.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link to="/dashboard" className="bg-brand-600 hover:bg-brand-500 text-white text-lg px-8 py-4 rounded-full font-semibold transition-all flex items-center justify-center gap-2">
            Start Free Trial <ArrowRight className="w-5 h-5" />
          </Link>
          <button className="bg-slate-800 hover:bg-slate-700 text-white text-lg px-8 py-4 rounded-full font-semibold transition-all">
            View Demo
          </button>
        </div>
        
        {/* Hero Image Placeholder */}
        <div className="mt-20 relative mx-auto max-w-5xl">
          <div className="absolute -inset-1 bg-gradient-to-r from-brand-500 to-purple-600 rounded-2xl blur opacity-30"></div>
          <div className="relative bg-slate-900 border border-slate-800 rounded-2xl p-2 shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=2400&q=80" 
              alt="Dashboard Preview" 
              className="rounded-xl opacity-80 grayscale hover:grayscale-0 transition-all duration-700"
            />
          </div>
        </div>
      </header>

      {/* Features Grid */}
      <section className="bg-slate-900 py-24">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-12">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-brand-500/10 rounded-xl flex items-center justify-center text-brand-500 mb-4">
                <BarChart3 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold">Predictive Analytics</h3>
              <p className="text-slate-400 leading-relaxed">
                Know what your customers want before they do. Our AI analyzes millions of data points to predict LTV and churn risk.
              </p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500 mb-4">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold">Customer DNA</h3>
              <p className="text-slate-400 leading-relaxed">
                360° profiles that update in real-time. Segment your audience dynamically based on behavior, not just demographics.
              </p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-purple-500/10 rounded-xl flex items-center justify-center text-purple-500 mb-4">
                <Globe className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold">Omnichannel Growth</h3>
              <p className="text-slate-400 leading-relaxed">
                Seamlessly orchestrate campaigns across Email, SMS, WhatsApp, and Social Media from a single command center.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-24 border-t border-slate-900">
        <div className="container mx-auto px-6 text-center">
            <p className="text-slate-500 font-medium mb-8 uppercase tracking-wider">Trusted by 10,000+ fast-growing brands</p>
            <div className="flex flex-wrap justify-center gap-12 opacity-50 grayscale">
                <div className="text-2xl font-bold">SHOPIFY</div>
                <div className="text-2xl font-bold">WOOCOMMERCE</div>
                <div className="text-2xl font-bold">BIGCOMMERCE</div>
                <div className="text-2xl font-bold">MAGENTO</div>
            </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-12">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-slate-700" />
            <span className="font-bold text-slate-700">BuzzBit X</span>
          </div>
          <div className="text-slate-600 text-sm">
            © 2023 BuzzBit Inc. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

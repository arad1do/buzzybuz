import React, { useState } from 'react';
import { Search, Filter, MessageCircle, Phone, Mail, Paperclip, Send, MoreVertical, CheckCircle } from 'lucide-react';
import { InboxThread } from '../types';

const threads: InboxThread[] = [
  { id: '1', customerName: 'Sarah Jenkins', lastMessage: 'I haven\'t received my tracking number yet.', platform: 'whatsapp', timestamp: '10:42 AM', unread: true, tags: ['Support', 'Order'] },
  { id: '2', customerName: 'Mike Ross', lastMessage: 'Can I return the shoes if they don\'t fit?', platform: 'chat', timestamp: 'Yesterday', unread: false, tags: ['Question'] },
  { id: '3', customerName: 'Emily Blunt', lastMessage: 'Thanks for the discount code!', platform: 'sms', timestamp: 'Yesterday', unread: false, tags: ['Feedback'] },
  { id: '4', customerName: 'John Wick', lastMessage: 'Where is my dog collar?', platform: 'email', timestamp: '2 days ago', unread: false, tags: ['Urgent'] },
];

export const Inbox: React.FC = () => {
  const [selectedThread, setSelectedThread] = useState<string | null>(threads[0].id);
  const [replyText, setReplyText] = useState('');

  const currentThread = threads.find(t => t.id === selectedThread);

  return (
    <div className="h-[calc(100vh-140px)] flex bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Thread List */}
      <div className="w-80 border-r border-slate-800 flex flex-col bg-slate-900">
        <div className="p-4 border-b border-slate-800">
          <h2 className="text-lg font-bold text-white mb-3">Inbox</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search messages..." 
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-sm text-white focus:border-brand-500 outline-none"
            />
          </div>
          <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
            <button className="px-3 py-1 bg-slate-800 text-white text-xs rounded-full whitespace-nowrap">All</button>
            <button className="px-3 py-1 border border-slate-700 text-slate-400 text-xs rounded-full whitespace-nowrap">Unread</button>
            <button className="px-3 py-1 border border-slate-700 text-slate-400 text-xs rounded-full whitespace-nowrap">WhatsApp</button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          {threads.map((thread) => (
            <div 
              key={thread.id}
              onClick={() => setSelectedThread(thread.id)}
              className={`p-4 border-b border-slate-800/50 cursor-pointer hover:bg-slate-800/50 transition-colors ${selectedThread === thread.id ? 'bg-slate-800/80 border-l-2 border-l-brand-500' : ''}`}
            >
              <div className="flex justify-between items-start mb-1">
                <h3 className={`font-medium text-sm ${thread.unread ? 'text-white' : 'text-slate-300'}`}>{thread.customerName}</h3>
                <span className="text-xs text-slate-500">{thread.timestamp}</span>
              </div>
              <p className={`text-xs line-clamp-2 mb-2 ${thread.unread ? 'text-slate-200 font-medium' : 'text-slate-500'}`}>
                {thread.lastMessage}
              </p>
              <div className="flex items-center gap-2">
                {thread.platform === 'whatsapp' && <MessageCircle className="w-3 h-3 text-green-500" />}
                {thread.platform === 'sms' && <Phone className="w-3 h-3 text-blue-500" />}
                {thread.platform === 'email' && <Mail className="w-3 h-3 text-yellow-500" />}
                <span className="text-xs text-slate-500 capitalize">{thread.platform}</span>
                {thread.tags.map(tag => (
                  <span key={tag} className="px-1.5 py-0.5 bg-slate-800 rounded text-[10px] text-slate-400">{tag}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col bg-slate-950/50">
        {/* Header */}
        <div className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-brand-500 flex items-center justify-center text-white font-bold">
              {currentThread?.customerName.charAt(0)}
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">{currentThread?.customerName}</h3>
              <p className="text-xs text-slate-400">Last active: {currentThread?.timestamp}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
                <CheckCircle className="w-5 h-5" />
            </button>
            <button className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
                <MoreVertical className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
           <div className="flex justify-center mb-4">
                <span className="px-3 py-1 bg-slate-800 rounded-full text-xs text-slate-400">Today</span>
           </div>
           
           {/* Customer Msg */}
           <div className="flex gap-3">
               <div className="w-8 h-8 rounded-full bg-slate-800 flex-shrink-0 flex items-center justify-center text-xs">SJ</div>
               <div className="max-w-[70%]">
                   <div className="bg-slate-800 rounded-2xl rounded-tl-none px-4 py-3 text-slate-200 text-sm">
                       {currentThread?.lastMessage}
                   </div>
               </div>
           </div>

           {/* Agent Reply Simulation */}
           <div className="flex gap-3 flex-row-reverse">
               <div className="w-8 h-8 rounded-full bg-brand-600 flex-shrink-0 flex items-center justify-center text-xs">You</div>
               <div className="max-w-[70%]">
                   <div className="bg-brand-600/20 border border-brand-600/30 rounded-2xl rounded-tr-none px-4 py-3 text-brand-100 text-sm">
                       Hi Sarah, I'm looking into that for you right now. One moment please!
                   </div>
                   <span className="text-[10px] text-slate-500 block text-right mt-1">Read 10:45 AM</span>
               </div>
           </div>
        </div>

        {/* Input */}
        <div className="p-4 border-t border-slate-800 bg-slate-900">
            <div className="relative">
                <textarea
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type your reply... (Press / for AI templates)"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-4 pr-12 py-3 text-sm text-white focus:border-brand-500 outline-none resize-none h-12 max-h-32"
                />
                <div className="absolute right-2 top-2 flex items-center gap-1">
                     <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors">
                        <Paperclip className="w-4 h-4" />
                     </button>
                     <button className="p-1.5 text-brand-500 hover:bg-brand-500/10 rounded transition-colors">
                        <Send className="w-4 h-4" />
                     </button>
                </div>
            </div>
            <div className="flex items-center gap-2 mt-2">
                <button className="text-xs text-brand-400 hover:underline">Suggest AI Reply</button>
                <span className="text-slate-600">•</span>
                <span className="text-xs text-slate-500">Press Enter to send</span>
            </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, Send, Loader2, Sparkles, User, BrainCircuit, PenTool, 
  GitMerge, HelpCircle, Terminal, Play, CheckCircle, FileText, 
  Image as ImageIcon, Database, Globe, Code, Zap, ArrowRight,
  Clock, AlertCircle, StopCircle, MessageCircle
} from 'lucide-react';
import { chatWithAI, generateAgentPlan, generateMarketingCopy } from '../services/geminiService';
import { ChatMessage, AgentStep, AgentArtifact } from '../types';

export const AIPlanner: React.FC = () => {
  // Mode Selection
  const [mode, setMode] = useState<'interactive' | 'autonomous' | 'support'>('autonomous');
  
  // Autonomous State
  const [taskInput, setTaskInput] = useState('');
  const [isPlanning, setIsPlanning] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [steps, setSteps] = useState<AgentStep[]>([]);
  const [artifacts, setArtifacts] = useState<AgentArtifact[]>([]);
  const [currentStepId, setCurrentStepId] = useState<string | null>(null);
  const [terminalLogs, setTerminalLogs] = useState<string[]>(["> System initialized.", "> Waiting for command..."]);
  
  // Interactive State (Legacy)
  const [messages, setMessages] = useState<ChatMessage[]>([{ id: 'w', role: 'model', text: 'Hello! I am your BuzzBit X AI Assistant. How can I help you today?', timestamp: new Date() }]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const terminalRef = useRef<HTMLDivElement>(null);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);
  useEffect(() => { 
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalLogs]);

  // --- AUTONOMOUS LOGIC ---

  const addLog = (msg: string) => {
    setTerminalLogs(prev => [...prev, `> ${msg}`]);
  };

  const handleStartTask = async () => {
    if (!taskInput.trim()) return;
    
    setIsPlanning(true);
    setSteps([]);
    setArtifacts([]);
    setTerminalLogs(["> Analyzing request...", `> Goal: "${taskInput}"`]);
    
    // 1. Generate Plan
    const plan = await generateAgentPlan(taskInput);
    setSteps(plan);
    setIsPlanning(false);
    setIsExecuting(true);
    addLog("Plan generated. Starting execution engine...");

    // 2. Execute Steps Sequentially
    await executePlan(plan);
  };

  const executePlan = async (plan: AgentStep[]) => {
    for (const step of plan) {
      setCurrentStepId(step.id);
      setSteps(prev => prev.map(s => s.id === step.id ? { ...s, status: 'running' } : s));
      addLog(`Executing: ${step.label}`);
      
      // Simulate processing time varies by tool
      const duration = Math.random() * 2000 + 1500; 
      
      // Visual "Thinking" updates
      await new Promise(r => setTimeout(r, duration / 2));
      addLog(`[${step.tool.toUpperCase()}] Processing data...`);
      await new Promise(r => setTimeout(r, duration / 2));

      // Generate Artifacts for "create" steps
      if (step.tool === 'create') {
        if (step.label.toLowerCase().includes('email')) {
          const content = await generateMarketingCopy(taskInput, 'email', 'Professional');
          const artifact: AgentArtifact = {
             id: Date.now().toString(),
             type: 'email',
             title: 'Draft Email Campaign',
             content: content
          };
          setArtifacts(prev => [...prev, artifact]);
          addLog("Artifact generated: Email Draft");
        } else if (step.label.toLowerCase().includes('image') || step.label.toLowerCase().includes('banner')) {
           const artifact: AgentArtifact = {
             id: Date.now().toString(),
             type: 'image',
             title: 'Campaign Banner',
             content: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80'
           };
           setArtifacts(prev => [...prev, artifact]);
           addLog("Artifact generated: Image Asset");
        }
      }

      setSteps(prev => prev.map(s => s.id === step.id ? { ...s, status: 'completed' } : s));
      addLog(`Completed: ${step.label}`);
    }

    setIsExecuting(false);
    setCurrentStepId(null);
    addLog("All tasks completed successfully.");
    addLog("Waiting for next command.");
  };

  // --- INTERACTIVE LOGIC ---

  const handleChatSend = async () => {
    if (!taskInput.trim()) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: taskInput, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setTaskInput('');
    
    const response = await chatWithAI(userMsg.text, messages.map(m => ({ role: m.role, parts: [{ text: m.text }] })));
    setMessages(prev => [...prev, { id: (Date.now()+1).toString(), role: 'model', text: response, timestamp: new Date() }]);
  };

  // --- RENDERERS ---

  const renderIcon = (tool: string) => {
      switch(tool) {
          case 'analysis': return <Database className="w-4 h-4 text-blue-400" />;
          case 'create': return <PenTool className="w-4 h-4 text-purple-400" />;
          case 'browser': return <Globe className="w-4 h-4 text-orange-400" />;
          case 'api': return <Code className="w-4 h-4 text-emerald-400" />;
          default: return <Terminal className="w-4 h-4 text-slate-400" />;
      }
  };

  return (
    <div className="h-[calc(100vh-100px)] flex flex-col bg-slate-950">
      {/* Header / Mode Switcher */}
      <div className="flex justify-between items-center mb-6 px-2">
          <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Bot className="w-8 h-8 text-brand-500" />
                  BuzzBit X Agent
              </h1>
              <p className="text-slate-400 text-sm">Autonomous Operations Center</p>
          </div>
          <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
              <button onClick={() => setMode('autonomous')} className={`px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-all ${mode === 'autonomous' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>
                  <Zap className="w-4 h-4" /> Autonomous
              </button>
              <button onClick={() => setMode('interactive')} className={`px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-all ${mode === 'interactive' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>
                  <MessageCircle className="w-4 h-4" /> Chat
              </button>
              <button onClick={() => setMode('support')} className={`px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-all ${mode === 'support' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>
                  <HelpCircle className="w-4 h-4" /> Support
              </button>
          </div>
      </div>

      {/* --- AUTONOMOUS MODE --- */}
      {mode === 'autonomous' && (
        <div className="flex-1 flex gap-6 overflow-hidden">
            {/* Left: Input & Plan */}
            <div className="w-1/3 flex flex-col gap-6">
                {/* Input Area */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col gap-4 shadow-lg">
                    <h3 className="text-white font-bold flex items-center gap-2">
                        <BrainCircuit className="w-5 h-5 text-brand-400" />
                        Task Input
                    </h3>
                    <textarea 
                        value={taskInput}
                        onChange={(e) => setTaskInput(e.target.value)}
                        disabled={isExecuting || isPlanning}
                        placeholder="e.g. Create a Black Friday email campaign for VIP customers and set up a tracking segment."
                        className="w-full h-32 bg-slate-950 border border-slate-700 rounded-lg p-4 text-white resize-none focus:border-brand-500 outline-none disabled:opacity-50"
                    />
                    <button 
                        onClick={handleStartTask}
                        disabled={isExecuting || isPlanning || !taskInput.trim()}
                        className="w-full bg-brand-600 hover:bg-brand-500 disabled:bg-slate-800 disabled:text-slate-500 text-white py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition-all"
                    >
                        {isPlanning ? <Loader2 className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5" />}
                        {isPlanning ? 'Generating Plan...' : isExecuting ? 'Executing...' : 'Start Autonomous Task'}
                    </button>
                </div>

                {/* Plan Execution View */}
                <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-6 overflow-hidden flex flex-col shadow-lg">
                    <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                        <GitMerge className="w-5 h-5 text-blue-400" />
                        Execution Plan
                    </h3>
                    <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                        {steps.length === 0 && !isPlanning && (
                            <div className="text-center text-slate-500 mt-10 italic">
                                No active plan. Enter a task to begin.
                            </div>
                        )}
                        {steps.map((step, idx) => (
                            <div key={step.id} className={`p-3 rounded-lg border flex items-center gap-3 transition-all ${
                                step.status === 'running' ? 'bg-brand-900/20 border-brand-500/50 shadow-[0_0_15px_rgba(20,184,166,0.1)]' : 
                                step.status === 'completed' ? 'bg-slate-800/50 border-slate-700 opacity-70' :
                                'bg-slate-900 border-slate-800 text-slate-500'
                            }`}>
                                <div className="w-6 h-6 flex-shrink-0 flex items-center justify-center">
                                    {step.status === 'completed' && <CheckCircle className="w-5 h-5 text-emerald-500" />}
                                    {step.status === 'running' && <Loader2 className="w-5 h-5 text-brand-400 animate-spin" />}
                                    {step.status === 'pending' && <div className="w-2 h-2 rounded-full bg-slate-600" />}
                                </div>
                                <div className="flex-1">
                                    <p className={`text-sm font-medium ${step.status === 'running' ? 'text-brand-100' : step.status === 'completed' ? 'text-slate-300' : 'text-slate-500'}`}>
                                        {step.label}
                                    </p>
                                </div>
                                <div className="p-1.5 rounded bg-slate-950 border border-slate-800">
                                    {renderIcon(step.tool)}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Right: BuzzBit's Computer (Terminal & Artifacts) */}
            <div className="flex-1 flex flex-col gap-6">
                {/* Terminal */}
                <div className="h-1/2 bg-[#0f172a] border border-slate-700 rounded-xl p-0 flex flex-col shadow-2xl font-mono overflow-hidden">
                    <div className="bg-slate-800 p-2 px-4 flex items-center gap-2 border-b border-slate-700">
                        <Terminal className="w-4 h-4 text-slate-400" />
                        <span className="text-xs text-slate-300 font-bold">BuzzBit OS v2.5.0</span>
                        <div className="ml-auto flex gap-1.5">
                            <div className="w-2.5 h-2.5 rounded-full bg-red-500/50"></div>
                            <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50"></div>
                            <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
                        </div>
                    </div>
                    <div className="flex-1 p-4 overflow-y-auto text-sm space-y-1" ref={terminalRef}>
                         {terminalLogs.map((log, i) => (
                             <div key={i} className={`break-words ${log.startsWith('>') ? 'text-brand-400' : 'text-slate-300'}`}>
                                 {log}
                             </div>
                         ))}
                         {isExecuting && (
                             <div className="flex items-center gap-1 text-brand-400">
                                 <span>_</span>
                                 <span className="animate-pulse">█</span>
                             </div>
                         )}
                    </div>
                </div>

                {/* Artifacts Output */}
                <div className="h-1/2 bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col shadow-lg">
                    <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                        <FileText className="w-5 h-5 text-purple-400" />
                        Generated Artifacts
                    </h3>
                    <div className="flex-1 overflow-y-auto grid grid-cols-2 gap-4 content-start">
                        {artifacts.length === 0 && (
                            <div className="col-span-2 flex flex-col items-center justify-center text-slate-500 h-full border-2 border-dashed border-slate-800 rounded-xl">
                                <Sparkles className="w-8 h-8 mb-2 opacity-50" />
                                <p className="text-sm">Outputs will appear here...</p>
                            </div>
                        )}
                        {artifacts.map(art => (
                            <div key={art.id} className="bg-slate-800 border border-slate-700 rounded-lg p-4 hover:border-brand-500 transition-all group cursor-pointer flex flex-col">
                                <div className="flex items-center justify-between mb-3">
                                    <div className="p-2 bg-slate-900 rounded">
                                        {art.type === 'email' && <FileText className="w-5 h-5 text-blue-400" />}
                                        {art.type === 'image' && <ImageIcon className="w-5 h-5 text-pink-400" />}
                                    </div>
                                    <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-900 px-2 py-1 rounded">{art.type}</span>
                                </div>
                                <h4 className="text-white font-bold text-sm mb-2">{art.title}</h4>
                                {art.type === 'image' && art.content.startsWith('http') ? (
                                    <div className="h-24 w-full rounded bg-slate-950 overflow-hidden mb-2">
                                        <img src={art.content} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" alt="Artifact" />
                                    </div>
                                ) : (
                                    <p className="text-xs text-slate-400 line-clamp-3 mb-2 font-mono bg-slate-950 p-2 rounded border border-slate-800">
                                        {art.content}
                                    </p>
                                )}
                                <div className="mt-auto pt-2 border-t border-slate-700 flex justify-end">
                                    <button className="text-xs text-brand-400 hover:underline flex items-center gap-1">
                                        View Details <ArrowRight className="w-3 h-3" />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
      )}

      {/* --- INTERACTIVE MODE (Legacy Chat) --- */}
      {mode === 'interactive' && (
        <div className="flex-1 flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg mx-4 mb-4">
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${msg.role === 'user' ? 'bg-slate-700' : 'bg-brand-600'}`}>
                            {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
                        </div>
                        <div className={`max-w-[80%] rounded-2xl px-5 py-4 text-sm whitespace-pre-wrap ${msg.role === 'user' ? 'bg-slate-800 text-white' : 'bg-slate-950 border border-slate-800 text-slate-200'}`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>
            <div className="p-4 bg-slate-900 border-t border-slate-800 relative">
                <input 
                    type="text" 
                    value={taskInput} 
                    onChange={e => setTaskInput(e.target.value)} 
                    onKeyDown={e => e.key === 'Enter' && handleChatSend()} 
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-5 pr-14 py-4 text-white outline-none focus:border-brand-500 transition-all" 
                    placeholder="Chat with BuzzBit X..." 
                />
                <button onClick={handleChatSend} className="absolute right-6 top-6 text-brand-500 hover:text-brand-400 p-1">
                    <Send className="w-5 h-5" />
                </button>
            </div>
        </div>
      )}
      
      {/* --- SUPPORT MODE --- */}
      {mode === 'support' && (
           <div className="flex-1 flex items-center justify-center text-slate-500 flex-col gap-4">
               <HelpCircle className="w-16 h-16 opacity-20" />
               <p>Support Agent Mode coming soon...</p>
           </div>
      )}
    </div>
  );
};

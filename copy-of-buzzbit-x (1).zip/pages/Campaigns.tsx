import React, { useState } from 'react';
import { Plus, Mail, MessageCircle, Smartphone, Sparkles, Check, X, Loader2 } from 'lucide-react';
import { Campaign } from '../types';
import { generateMarketingCopy } from '../services/geminiService';

const initialCampaigns: Campaign[] = [
  { id: '1', name: 'Summer Clearance', status: 'active', channel: 'email', sent: 15000, openRate: 24.5, clickRate: 3.2, revenue: 12400, createdAt: '2023-10-01' },
  { id: '2', name: 'Cart Abandonment Flow', status: 'active', channel: 'sms', sent: 840, openRate: 92.0, clickRate: 15.4, revenue: 3200, createdAt: '2023-10-05' },
  { id: '3', name: 'VIP Early Access', status: 'scheduled', channel: 'whatsapp', sent: 0, openRate: 0, clickRate: 0, revenue: 0, createdAt: '2023-10-08' },
];

export const Campaigns: React.FC = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>(initialCampaigns);
  const [showModal, setShowModal] = useState(false);
  
  // Modal State
  const [campaignName, setCampaignName] = useState('');
  const [channel, setChannel] = useState<'email' | 'sms' | 'whatsapp'>('email');
  const [topic, setTopic] = useState('');
  const [tone, setTone] = useState('Professional yet Urgent');
  const [generatedContent, setGeneratedContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!topic) return;
    setIsGenerating(true);
    const content = await generateMarketingCopy(topic, channel, tone);
    setGeneratedContent(content);
    setIsGenerating(false);
  };

  const handleCreate = () => {
    const newCampaign: Campaign = {
      id: Date.now().toString(),
      name: campaignName || 'Untitled Campaign',
      status: 'draft',
      channel,
      sent: 0,
      openRate: 0,
      clickRate: 0,
      revenue: 0,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setCampaigns([newCampaign, ...campaigns]);
    setShowModal(false);
    resetForm();
  };

  const resetForm = () => {
    setCampaignName('');
    setTopic('');
    setGeneratedContent('');
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">Campaigns</h1>
          <p className="text-slate-400">Manage your multi-channel marketing flows.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 bg-brand-600 hover:bg-brand-500 text-white px-4 py-2 rounded-lg transition-all shadow-lg shadow-brand-500/20"
        >
          <Plus className="w-4 h-4" />
          New Campaign
        </button>
      </div>

      {/* Campaign List */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <table className="w-full text-left text-sm text-slate-400">
          <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium">
            <tr>
              <th className="px-6 py-4">Campaign Name</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4">Channel</th>
              <th className="px-6 py-4 text-right">Sent</th>
              <th className="px-6 py-4 text-right">Engagement</th>
              <th className="px-6 py-4 text-right">Revenue</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {campaigns.map((campaign) => (
              <tr key={campaign.id} className="hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-4 font-medium text-white">{campaign.name}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium border ${
                    campaign.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                    campaign.status === 'scheduled' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' :
                    'bg-slate-700/50 text-slate-300 border-slate-600'
                  }`}>
                    {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2 text-slate-300">
                    {campaign.channel === 'email' && <Mail className="w-4 h-4" />}
                    {campaign.channel === 'sms' && <Smartphone className="w-4 h-4" />}
                    {campaign.channel === 'whatsapp' && <MessageCircle className="w-4 h-4" />}
                    <span className="capitalize">{campaign.channel}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right">{campaign.sent.toLocaleString()}</td>
                <td className="px-6 py-4 text-right">
                    <div className="flex flex-col items-end gap-1">
                        <span className="text-emerald-400">{campaign.openRate}% Open</span>
                        <span className="text-xs">{campaign.clickRate}% Click</span>
                    </div>
                </td>
                <td className="px-6 py-4 text-right font-bold text-white">${campaign.revenue.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Create Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-brand-400" />
                AI Campaign Creator
              </h2>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Campaign Name</label>
                  <input 
                    type="text" 
                    value={campaignName}
                    onChange={(e) => setCampaignName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none"
                    placeholder="e.g., Black Friday Early Access"
                  />
                </div>

                <div className="col-span-2 md:col-span-1">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Channel</label>
                  <select 
                    value={channel}
                    onChange={(e) => setChannel(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white outline-none focus:border-brand-500"
                  >
                    <option value="email">Email Blast</option>
                    <option value="sms">SMS Marketing</option>
                    <option value="whatsapp">WhatsApp Business</option>
                  </select>
                </div>

                <div className="col-span-2 md:col-span-1">
                    <label className="block text-sm font-medium text-slate-300 mb-1">Tone of Voice</label>
                    <select 
                        value={tone}
                        onChange={(e) => setTone(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white outline-none focus:border-brand-500"
                    >
                        <option>Professional yet Urgent</option>
                        <option>Friendly and Casual</option>
                        <option>Luxury and Minimalist</option>
                        <option>Exciting and Energetic</option>
                    </select>
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">What is this campaign about?</label>
                  <textarea 
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white h-24 resize-none outline-none focus:border-brand-500"
                    placeholder="Describe the offer, products, or announcement..."
                  />
                </div>

                <div className="col-span-2">
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-brand-400">AI Generated Content</label>
                    <button 
                      onClick={handleGenerate}
                      disabled={isGenerating || !topic}
                      className="text-xs flex items-center gap-1 bg-brand-500/10 text-brand-400 px-3 py-1 rounded-full hover:bg-brand-500/20 disabled:opacity-50 transition-colors"
                    >
                      {isGenerating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                      {isGenerating ? 'Generating...' : 'Generate with Gemini'}
                    </button>
                  </div>
                  <div className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-4 text-slate-300 min-h-[150px] whitespace-pre-wrap font-mono text-sm">
                    {generatedContent || <span className="text-slate-600 italic">Enter a topic and click generate to see AI magic...</span>}
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-slate-800 bg-slate-900 flex justify-end gap-3">
              <button 
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-slate-400 hover:text-white transition-colors font-medium"
              >
                Cancel
              </button>
              <button 
                onClick={handleCreate}
                className="px-6 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-lg font-medium transition-colors shadow-lg shadow-brand-500/20 flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                Save Draft
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
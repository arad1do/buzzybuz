
import React, { useState } from 'react';
import { Maximize, Eye, MousePointer, Clock, LayoutTemplate, ToggleLeft, ToggleRight, Plus, Trash2, Layout, Type, Image as ImageIcon, X } from 'lucide-react';
import { Popup } from '../types';

export const Popups: React.FC = () => {
  const [view, setView] = useState<'list' | 'design'>('list');
  const [popups, setPopups] = useState<Popup[]>([
    { id: '1', name: 'Welcome Offer', type: 'timer', conversionRate: 12.5, status: 'active', views: 1240 },
    { id: '2', name: 'Cart Abandonment', type: 'exit-intent', conversionRate: 8.2, status: 'active', views: 450 },
  ]);

  return (
    <div className="space-y-6 h-[calc(100vh-100px)] flex flex-col">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Smart Popups</h1>
        {view === 'list' && (
            <button onClick={() => setView('design')} className="bg-brand-600 hover:bg-brand-500 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                <Plus className="w-4 h-4" /> Create Popup
            </button>
        )}
        {view === 'design' && (
            <button onClick={() => setView('list')} className="text-slate-400 hover:text-white">Cancel</button>
        )}
      </div>

      {view === 'list' ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
             {popups.map(p => (
                 <div key={p.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                     <div className="flex justify-between mb-4">
                         <h3 className="font-bold text-white">{p.name}</h3>
                         <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded">{p.status}</span>
                     </div>
                     <div className="h-32 bg-slate-950 rounded mb-4 flex items-center justify-center text-slate-600 text-xs">Preview</div>
                     <div className="flex justify-between text-sm text-slate-400">
                         <span>{p.conversionRate}% Conv.</span>
                         <button onClick={() => setView('design')} className="text-brand-400 hover:underline">Edit</button>
                     </div>
                 </div>
             ))}
          </div>
      ) : (
          <div className="flex-1 flex bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="w-64 border-r border-slate-800 p-4 bg-slate-950">
                  <h3 className="font-bold text-white mb-4">Components</h3>
                  <div className="space-y-2">
                      {['Headline', 'Text', 'Image', 'Button', 'Form Input', 'Countdown'].map(c => (
                          <div key={c} className="p-3 bg-slate-900 border border-slate-800 rounded text-slate-300 text-sm cursor-pointer hover:border-brand-500">{c}</div>
                      ))}
                  </div>
                  <h3 className="font-bold text-white mt-6 mb-4">Triggers</h3>
                  <div className="space-y-2">
                      <label className="flex items-center gap-2 text-slate-300 text-sm"><input type="checkbox" /> Exit Intent</label>
                      <label className="flex items-center gap-2 text-slate-300 text-sm"><input type="checkbox" /> Scroll 50%</label>
                      <label className="flex items-center gap-2 text-slate-300 text-sm"><input type="checkbox" /> Time (10s)</label>
                  </div>
              </div>
              <div className="flex-1 bg-slate-950/50 flex items-center justify-center p-10 relative">
                  <div className="absolute inset-0 bg-black/50 z-10"></div>
                  <div className="bg-white w-[400px] p-8 rounded-lg shadow-2xl z-20 relative text-center">
                      <button className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
                      <h2 className="text-2xl font-bold text-gray-900 mb-2">Wait! Don't Go.</h2>
                      <p className="text-gray-600 mb-6">Get 10% off your first order if you checkout now.</p>
                      <button className="bg-black text-white w-full py-3 rounded font-bold hover:bg-gray-800">REVEAL CODE</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};


import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, MessageSquare, Settings, Zap, Activity, MessageCircle, 
  CheckCircle, AlertTriangle, User, RefreshCcw, Plus,
  PieChart, Gauge, Terminal, Play, Edit3, ToggleLeft, ToggleRight,
  Smile, Briefcase, Coffee, Crown, Sparkles, Send, Loader2,
  Clock
} from 'lucide-react';
import { Intent, BrandToneConfig, FollowUpRule, ChatMessage } from '../types';
import { simulateWhatsAppAgent } from '../services/geminiService';

// --- MOCK DATA ---

const MOCK_INTENTS: Intent[] = [
  { id: '1', name: 'Product Inquiry', category: 'sales', description: 'Questions about product details', triggers: ['price', 'cost', 'details'], responseTemplate: 'AI Generated', isEnabled: true, automationRate: 95 },
  { id: '2', name: 'Order Status', category: 'service', description: 'Where is my order?', triggers: ['tracking', 'where', 'status'], responseTemplate: 'Status lookup', isEnabled: true, automationRate: 98 },
  { id: '3', name: 'Returns', category: 'service', description: 'Return policy and process', triggers: ['return', 'refund', 'back'], responseTemplate: 'Return policy flow', isEnabled: true, automationRate: 85 },
  { id: '4', name: 'Booking', category: 'booking', description: 'Schedule appointments', triggers: ['book', 'schedule', 'time'], responseTemplate: 'Booking flow', isEnabled: false, automationRate: 0 },
  { id: '5', name: 'Escalation', category: 'service', description: 'Speak to human', triggers: ['human', 'agent', 'person'], responseTemplate: 'Handover', isEnabled: true, automationRate: 0 },
  { id: '6', name: 'Discount Request', category: 'sales', triggers: ['discount', 'coupon', 'sale'], description: 'Provide active codes', responseTemplate: 'Discount flow', isEnabled: true, automationRate: 92 },
];

const MOCK_FOLLOWUPS: FollowUpRule[] = [
  { id: 'f1', type: 'abandoned_cart', name: 'Cart Recovery (1hr)', delay: 60, isEnabled: true, template: 'Hi {{name}}, you left items in your cart...' },
  { id: 'f2', type: 'post_purchase', name: 'Thank You + Upsell', delay: 1440, isEnabled: true, template: 'Thanks for ordering! Check out these matching items...' },
  { id: 'f3', type: 'win_back', name: 'We Miss You (30d)', delay: 43200, isEnabled: false, template: 'It\'s been a while! Here is 10% off.' },
];

// --- COMPONENT ---

export const WhatsAppAgent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'intents' | 'personality' | 'followups' | 'simulator'>('dashboard');
  
  // Configuration State
  const [brandTone, setBrandTone] = useState<BrandToneConfig>({
    preset: 'friendly',
    customInstructions: 'Use emojis moderately. Be helpful but concise.',
    emojiUsage: 'moderate'
  });
  const [intents, setIntents] = useState(MOCK_INTENTS);
  const [followUps, setFollowUps] = useState(MOCK_FOLLOWUPS);

  // Simulator State
  const [simMessages, setSimMessages] = useState<ChatMessage[]>([
    { id: 'init', role: 'model', text: 'Hi! I am your configured WhatsApp Agent simulation. Send me a message to test my responses.', timestamp: new Date() }
  ]);
  const [simInput, setSimInput] = useState('');
  const [isSimulating, setIsSimulating] = useState(false);
  const simEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    simEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [simMessages, activeTab]);

  const handleSimulate = async () => {
    if (!simInput.trim() || isSimulating) return;

    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: simInput, timestamp: new Date() };
    setSimMessages(prev => [...prev, userMsg]);
    setSimInput('');
    setIsSimulating(true);

    // Call Gemini Service
    const result = await simulateWhatsAppAgent(simInput, brandTone.preset, `Custom Instructions: ${brandTone.customInstructions}`);

    const agentMsg: ChatMessage = { id: (Date.now()+1).toString(), role: 'model', text: result.text, timestamp: new Date() };
    setSimMessages(prev => [...prev, agentMsg]);
    setIsSimulating(false);
  };

  const toggleIntent = (id: string) => {
    setIntents(intents.map(i => i.id === id ? { ...i, isEnabled: !i.isEnabled } : i));
  };

  const toggleFollowUp = (id: string) => {
    setFollowUps(followUps.map(f => f.id === id ? { ...f, isEnabled: !f.isEnabled } : f));
  };

  return (
    <div className="space-y-6 h-[calc(100vh-100px)] flex flex-col">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Bot className="w-7 h-7 text-brand-500" />
            WhatsApp AI Agent
          </h1>
          <p className="text-slate-400">Configure your 24/7 automated sales and support force.</p>
        </div>
        <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
          {['dashboard', 'intents', 'personality', 'followups', 'simulator'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-4 py-2 rounded-md text-sm font-medium capitalize transition-all ${
                activeTab === tab ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto">
        
        {/* --- DASHBOARD --- */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
                <div className="flex justify-between items-start mb-2">
                  <Zap className="w-5 h-5 text-brand-400" />
                  <span className="text-xs text-emerald-400 font-medium bg-emerald-500/10 px-2 py-0.5 rounded-full">+2.5%</span>
                </div>
                <p className="text-slate-400 text-sm">Automation Rate</p>
                <p className="text-2xl font-bold text-white">94.2%</p>
              </div>
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
                <div className="flex justify-between items-start mb-2">
                  <MessageCircle className="w-5 h-5 text-blue-400" />
                  <span className="text-xs text-slate-500 font-medium">Last 24h</span>
                </div>
                <p className="text-slate-400 text-sm">Conversations</p>
                <p className="text-2xl font-bold text-white">1,240</p>
              </div>
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
                <div className="flex justify-between items-start mb-2">
                  <User className="w-5 h-5 text-purple-400" />
                  <span className="text-xs text-red-400 font-medium bg-red-500/10 px-2 py-0.5 rounded-full">-1.2%</span>
                </div>
                <p className="text-slate-400 text-sm">Escalation Rate</p>
                <p className="text-2xl font-bold text-white">5.8%</p>
              </div>
              <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
                <div className="flex justify-between items-start mb-2">
                  <Clock className="w-5 h-5 text-orange-400" />
                  <span className="text-xs text-emerald-400 font-medium bg-emerald-500/10 px-2 py-0.5 rounded-full">-0.5s</span>
                </div>
                <p className="text-slate-400 text-sm">Avg Response</p>
                <p className="text-2xl font-bold text-white">1.2s</p>
              </div>
            </div>

            {/* Live Feed Mockup */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="p-4 border-b border-slate-800 flex justify-between items-center">
                <h3 className="font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-brand-500 animate-pulse" /> Live Activity
                </h3>
                <span className="text-xs text-slate-500">Real-time processing</span>
              </div>
              <div className="divide-y divide-slate-800">
                {[1,2,3,4,5].map((_, i) => (
                  <div key={i} className="p-4 hover:bg-slate-800/50 transition-colors flex gap-4 items-start">
                    <div className={`mt-1 w-2 h-2 rounded-full ${i===0 ? 'bg-brand-500' : 'bg-slate-600'}`}></div>
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-white">+1 (555) 000-123{i}</span>
                        <span className="text-xs text-slate-500">Just now</span>
                      </div>
                      <p className="text-xs text-slate-400">Intent detected: <span className="text-brand-400">product_inquiry</span> (98%)</p>
                      <p className="text-xs text-slate-500 mt-1">"Do you have this in blue?"</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* --- INTENTS --- */}
        {activeTab === 'intents' && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center">
              <div>
                 <h2 className="text-lg font-bold text-white">Intent Library</h2>
                 <p className="text-slate-400 text-sm">Manage what your agent understands.</p>
              </div>
              <button className="bg-brand-600 hover:bg-brand-500 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2">
                <Plus className="w-4 h-4" /> Custom Intent
              </button>
            </div>
            <table className="w-full text-left text-sm text-slate-400">
              <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium">
                <tr>
                  <th className="px-6 py-4">Intent Name</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4">Automation %</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {intents.map((intent) => (
                  <tr key={intent.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-medium text-white">{intent.name}</p>
                      <p className="text-xs text-slate-500">{intent.description}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-slate-800 rounded border border-slate-700 capitalize text-xs">
                        {intent.category}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-brand-500" style={{ width: `${intent.automationRate}%` }}></div>
                        </div>
                        <span className="text-xs">{intent.automationRate}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <button onClick={() => toggleIntent(intent.id)} className={`transition-colors ${intent.isEnabled ? 'text-brand-400' : 'text-slate-600'}`}>
                        {intent.isEnabled ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
                      </button>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-slate-400 hover:text-white"><Edit3 className="w-4 h-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* --- PERSONALITY --- */}
        {activeTab === 'personality' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
               <h2 className="text-lg font-bold text-white mb-4">Tone Preset</h2>
               <div className="space-y-3">
                 {[
                   { id: 'professional', icon: Briefcase, label: 'Professional', desc: 'Formal, courteous, precise' },
                   { id: 'friendly', icon: Smile, label: 'Friendly', desc: 'Warm, casual, helpful' },
                   { id: 'energetic', icon: Zap, label: 'Energetic', desc: 'Enthusiastic, motivating, bold' },
                   { id: 'luxury', icon: Crown, label: 'Luxury', desc: 'Sophisticated, exclusive, refined' },
                   { id: 'minimalist', icon: Coffee, label: 'Minimalist', desc: 'Simple, direct, efficient' },
                 ].map((preset) => (
                   <div 
                      key={preset.id}
                      onClick={() => setBrandTone({ ...brandTone, preset: preset.id as any })}
                      className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                        brandTone.preset === preset.id 
                          ? 'bg-brand-500/10 border-brand-500' 
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                      }`}
                   >
                      <div className={`p-2 rounded-lg ${brandTone.preset === preset.id ? 'bg-brand-500 text-white' : 'bg-slate-800 text-slate-400'}`}>
                         <preset.icon className="w-5 h-5" />
                      </div>
                      <div>
                         <h3 className={`font-bold ${brandTone.preset === preset.id ? 'text-brand-400' : 'text-white'}`}>{preset.label}</h3>
                         <p className="text-xs text-slate-500">{preset.desc}</p>
                      </div>
                      {brandTone.preset === preset.id && <CheckCircle className="w-5 h-5 text-brand-500 ml-auto" />}
                   </div>
                 ))}
               </div>
            </div>

            <div className="flex flex-col gap-6">
               <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex-1">
                  <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                     <Sparkles className="w-5 h-5 text-brand-400" /> Custom Instructions
                  </h2>
                  <p className="text-sm text-slate-400 mb-3">
                     Provide specific rules for the AI. E.g., "Never promise delivery dates," or "Always mention our warranty."
                  </p>
                  <textarea 
                     value={brandTone.customInstructions}
                     onChange={(e) => setBrandTone({ ...brandTone, customInstructions: e.target.value })}
                     className="w-full h-40 bg-slate-950 border border-slate-700 rounded-lg p-4 text-white text-sm focus:border-brand-500 outline-none resize-none"
                     placeholder="Enter custom behavior rules..."
                  />
               </div>

               <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                  <h2 className="text-lg font-bold text-white mb-4">Emoji Usage</h2>
                  <div className="flex gap-2">
                     {['none', 'minimal', 'moderate', 'frequent'].map(usage => (
                        <button
                           key={usage}
                           onClick={() => setBrandTone({ ...brandTone, emojiUsage: usage as any })}
                           className={`flex-1 py-2 rounded-lg text-sm font-medium border capitalize transition-all ${
                              brandTone.emojiUsage === usage 
                                ? 'bg-brand-600 text-white border-brand-500' 
                                : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                           }`}
                        >
                           {usage}
                        </button>
                     ))}
                  </div>
               </div>
            </div>
          </div>
        )}

        {/* --- FOLLOW UPS --- */}
        {activeTab === 'followups' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             {followUps.map(rule => (
               <div key={rule.id} className={`border rounded-xl p-6 transition-all ${rule.isEnabled ? 'bg-slate-900 border-brand-500/30' : 'bg-slate-900/50 border-slate-800 opacity-75'}`}>
                  <div className="flex justify-between items-start mb-4">
                     <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${rule.isEnabled ? 'bg-brand-500/20 text-brand-400' : 'bg-slate-800 text-slate-500'}`}>
                           <RefreshCcw className="w-5 h-5" />
                        </div>
                        <div>
                           <h3 className="font-bold text-white">{rule.name}</h3>
                           <p className="text-xs text-slate-400 capitalize">{rule.type.replace('_', ' ')} • {Math.round(rule.delay/60)}h Delay</p>
                        </div>
                     </div>
                     <button onClick={() => toggleFollowUp(rule.id)} className={rule.isEnabled ? 'text-brand-400' : 'text-slate-600'}>
                        {rule.isEnabled ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
                     </button>
                  </div>
                  <div className="bg-slate-950 rounded-lg p-4 border border-slate-800">
                     <p className="text-sm text-slate-300 font-mono whitespace-pre-wrap">{rule.template}</p>
                  </div>
                  <div className="mt-4 flex justify-end">
                     <button className="text-xs text-slate-400 hover:text-white flex items-center gap-1">
                        <Edit3 className="w-3 h-3" /> Edit Template
                     </button>
                  </div>
               </div>
             ))}
             
             <div className="border-2 border-dashed border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center text-slate-500 hover:text-brand-400 hover:border-brand-500/30 hover:bg-slate-900 transition-all cursor-pointer min-h-[200px]">
                <Plus className="w-10 h-10 mb-2" />
                <span className="font-medium">Add Follow-up Rule</span>
             </div>
          </div>
        )}

        {/* --- SIMULATOR --- */}
        {activeTab === 'simulator' && (
          <div className="h-[600px] flex gap-6">
             {/* Chat Window */}
             <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl flex flex-col overflow-hidden shadow-2xl">
                <div className="p-4 border-b border-slate-800 bg-slate-950/50 flex justify-between items-center">
                   <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-brand-600 flex items-center justify-center">
                         <Bot className="w-6 h-6 text-white" />
                      </div>
                      <div>
                         <h3 className="font-bold text-white">Agent Simulator</h3>
                         <p className="text-xs text-slate-400">Testing: <span className="capitalize text-brand-400">{brandTone.preset}</span> Tone</p>
                      </div>
                   </div>
                   <button onClick={() => setSimMessages([])} className="text-slate-500 hover:text-white p-2">
                      <RefreshCcw className="w-4 h-4" />
                   </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-[#0b141a]">
                   {simMessages.map(msg => (
                      <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                         <div className={`max-w-[80%] rounded-xl px-4 py-2 text-sm shadow-sm ${
                            msg.role === 'user' 
                              ? 'bg-[#005c4b] text-white rounded-tr-none' 
                              : 'bg-[#202c33] text-slate-200 rounded-tl-none'
                         }`}>
                            <p className="whitespace-pre-wrap">{msg.text}</p>
                            <span className="text-[10px] opacity-50 block text-right mt-1">
                               {msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </span>
                         </div>
                      </div>
                   ))}
                   {isSimulating && (
                      <div className="flex justify-start">
                         <div className="bg-[#202c33] rounded-xl rounded-tl-none px-4 py-3 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce"></span>
                            <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce delay-75"></span>
                            <span className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce delay-150"></span>
                         </div>
                      </div>
                   )}
                   <div ref={simEndRef} />
                </div>

                <div className="p-4 bg-[#202c33] border-t border-slate-800">
                   <div className="flex gap-2">
                      <input 
                        type="text"
                        value={simInput}
                        onChange={(e) => setSimInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSimulate()}
                        placeholder="Type a message..."
                        className="flex-1 bg-[#2a3942] text-white rounded-lg px-4 py-3 outline-none border border-transparent focus:border-brand-500/50"
                      />
                      <button 
                        onClick={handleSimulate}
                        disabled={isSimulating || !simInput.trim()}
                        className="bg-brand-600 hover:bg-brand-500 text-white p-3 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="w-5 h-5" />
                      </button>
                   </div>
                </div>
             </div>

             {/* Context Panel */}
             <div className="w-80 hidden xl:flex flex-col gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                   <h3 className="font-bold text-white mb-2 text-sm uppercase tracking-wider">Active Config</h3>
                   <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                         <span className="text-slate-500">Tone</span>
                         <span className="text-brand-400 capitalize">{brandTone.preset}</span>
                      </div>
                      <div className="flex justify-between">
                         <span className="text-slate-500">Emoji</span>
                         <span className="text-white capitalize">{brandTone.emojiUsage}</span>
                      </div>
                      <div className="flex justify-between">
                         <span className="text-slate-500">Active Intents</span>
                         <span className="text-emerald-400">{intents.filter(i => i.isEnabled).length}</span>
                      </div>
                   </div>
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex-1">
                   <h3 className="font-bold text-white mb-2 text-sm uppercase tracking-wider">Debug Log</h3>
                   <div className="space-y-2 overflow-y-auto max-h-[400px] pr-2">
                      {simMessages.filter(m => m.role === 'model').map(m => (
                         <div key={m.id} className="text-xs border-l-2 border-brand-500 pl-2 py-1">
                            <p className="text-slate-500 mb-0.5">Response Generated</p>
                            <p className="text-slate-300 truncate">{m.text}</p>
                         </div>
                      ))}
                   </div>
                </div>
             </div>
          </div>
        )}

      </div>
    </div>
  );
};

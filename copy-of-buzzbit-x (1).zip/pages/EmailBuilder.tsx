
import React, { useState } from 'react';
import { 
  Layout, Type, Image as ImageIcon, MousePointer, Save, Send, 
  ArrowRight, GitBranch, Plus, Clock, Mail, Smartphone, 
  CheckCircle, AlertCircle, ChevronRight, ChevronDown,
  Sparkles, Wand2, X, RotateCcw, ShoppingBag, Palette,
  Zap, Search, Layers, Workflow, Trash2, Settings, MoreHorizontal,
  Percent, Tag, Bell, ZoomIn, ZoomOut, Minimize
} from 'lucide-react';
import { optimizeEmailContent } from '../services/geminiService';
import { FlowNode, EmailTemplate, EmailElement, Product, NodeType } from '../types';

// --- CONSTANTS ---

const TRIGGER_CATEGORIES = [
  {
    title: "Behavioral",
    items: [
      "Cart abandoned", "Checkout started", "Product viewed 3+", "Category browsed", "Search w/o results",
      "Wishlist added", "Back-in-stock", "Price drop", "Similar purchased", "Compare products",
      "Exit intent", "Cart idle", "Multi-item cart", "High value cart", "Cart item removed",
      "Discount applied", "Cart threshold reached"
    ]
  },
  {
    title: "Transactional",
    items: [
      "Order placed", "Order shipped", "Order delivered", "Shipping notification", "Delivery confirmation",
      "Review request", "Return initiated", "Refund processed", "Subscription renewal", "Subscription created",
      "Subscription renewed", "Subscription cancelled", "Payment failed"
    ]
  },
  {
    title: "Lifecycle",
    items: [
      "New customer", "Account created", "Email verified", "Profile completed", "2nd purchase", "3rd purchase",
      "VIP tier reached", "Birthday", "Anniversary", "Account anniversary", "Inactive 30d", "Inactive 60d",
      "Inactive 90d", "Churn risk", "High-value ID", "Segment entered", "Referral made"
    ]
  },
  {
    title: "Engagement",
    items: [
      "Email opened", "Email clicked", "Email not opened", "Email opened 3+", "Link clicked no buy",
      "Replied to email", "Forwarded email", "Unsubscribed", "Resubscribed", "Preference updated",
      "Social share", "App installed", "Notifications enabled"
    ]
  },
  {
    title: "Inventory & Product",
    items: [
      "Back in stock", "Price drop", "Low stock", "New launch", "Discontinued", "Sale started", "Critical inventory"
    ]
  },
  {
    title: "Contextual",
    items: [
      "Weather-based", "Local event", "Trending topic", "Competitor mention", "Social buzz"
    ]
  },
  {
    title: "AI Powered",
    items: [
      "Hesitation detected", "Comparison shopping", "Rapid browsing", "Impulse buyer", "Bundle opportunity",
      "Payday detected", "Weather condition"
    ]
  }
];

const WORKFLOW_TEMPLATES = [
  {
    title: "Core Workflows",
    items: [
      "Welcome Series", "Cart Abandonment", "Checkout Abandonment", "Browse Abandonment", "Post-Purchase",
      "Win-Back", "VIP Nurture", "Birthday/Anniversary", "Product Launch", "Seasonal Campaign"
    ]
  },
  {
    title: "Specialized",
    items: [
      "Re-engagement", "Replenishment", "Review Request", "Referral Program", "Price Drop Alert",
      "Back in Stock", "Customer Education", "Loyalty Onboarding"
    ]
  },
  {
    title: "SMS & Multi-Channel",
    items: [
      "SMS Welcome", "SMS Cart Recovery", "SMS Flash Sale", "Omnichannel Recovery", "Cross-Channel Welcome", "Coordinated Launch"
    ]
  }
];

const INITIAL_TEMPLATE: EmailTemplate = {
  id: 'temp_1',
  name: 'Cart Abandonment V1',
  subject: 'Did you forget something?',
  previewText: 'Your items are waiting for you...',
  branding: { primaryColor: '#14b8a6', backgroundColor: '#ffffff', logoUrl: '' },
  elements: [
    { id: '1', type: 'image', content: '', src: 'https://images.unsplash.com/photo-1556742049-0cfed4f7a07d?auto=format&fit=crop&w=800&q=80', alt: 'Hero Image' },
    { id: '2', type: 'text', content: 'Wait! Your cart is expiring soon.', style: { fontSize: '24px', fontWeight: 'bold', textAlign: 'center', color: '#1e293b' } },
    { id: '3', type: 'text', content: 'We noticed you left some great items in your cart. We\'ve saved them for you, but stock is limited.', style: { fontSize: '16px', color: '#475569', textAlign: 'center', lineHeight: '1.5' } },
    { id: '4', type: 'button', content: 'Complete Purchase', link: '#', style: { backgroundColor: '#14b8a6', color: '#ffffff', padding: '16px 32px', borderRadius: '8px', fontWeight: 'bold', display: 'inline-block' } },
  ]
};

// --- COMPONENTS ---

const FlowNodeCard: React.FC<{ 
  node: FlowNode; 
  onClick: () => void; 
  isSelected: boolean;
}> = ({ node, onClick, isSelected }) => {
  const getIcon = () => {
    switch(node.type) {
      case 'trigger': return <Zap className="w-5 h-5 text-yellow-400" />;
      case 'action_email': return <Mail className="w-5 h-5 text-blue-400" />;
      case 'action_sms': return <Smartphone className="w-5 h-5 text-green-400" />;
      case 'delay': return <Clock className="w-5 h-5 text-orange-400" />;
      case 'condition': return <GitBranch className="w-5 h-5 text-purple-400" />;
      case 'split_random': return <Percent className="w-5 h-5 text-pink-400" />;
      case 'action_tag': return <Tag className="w-5 h-5 text-indigo-400" />;
      case 'action_notification': return <Bell className="w-5 h-5 text-red-400" />;
      default: return <CheckCircle className="w-5 h-5" />;
    }
  };

  const getBgColor = () => {
    if (isSelected) return 'border-brand-500 bg-slate-800 shadow-[0_0_15px_rgba(20,184,166,0.3)]';
    return 'border-slate-700 bg-slate-800/80 hover:border-slate-600 hover:shadow-lg';
  };

  return (
    <div 
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      className={`w-72 p-4 rounded-xl border-2 shadow-sm cursor-pointer transition-all duration-200 relative group backdrop-blur-sm ${getBgColor()}`}
    >
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-lg border border-slate-700 shadow-sm bg-slate-900`}>
          {getIcon()}
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-bold text-white text-sm truncate">{node.title}</h4>
          <p className="text-xs text-slate-400 truncate">{node.description}</p>
        </div>
        <MoreHorizontal className="w-4 h-4 text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
    </div>
  );
};

const AddNodeButton: React.FC<{ onClick: () => void }> = ({ onClick }) => (
  <button 
    onClick={(e) => { e.stopPropagation(); onClick(); }}
    className="w-8 h-8 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-slate-400 hover:bg-brand-600 hover:text-white hover:border-brand-500 transition-all z-10 shadow-md my-3 hover:scale-110"
  >
    <Plus className="w-4 h-4" />
  </button>
);

const FlowStep: React.FC<{ 
  node: FlowNode; 
  onSelect: (node: FlowNode) => void; 
  onAdd: (parentId: string, branch?: 'true' | 'false') => void;
  selectedNodeId: string | null;
}> = ({ node, onSelect, onAdd, selectedNodeId }) => {
  
  const isBranching = node.type === 'condition' || node.type === 'split_random';
  
  return (
    <div className="flex flex-col items-center">
      <FlowNodeCard 
        node={node} 
        onClick={() => onSelect(node)} 
        isSelected={selectedNodeId === node.id}
      />
      
      {isBranching ? (
        <div className="mt-8 flex gap-12 w-full relative justify-center min-w-[600px]">
           {/* Visual Lines */}
           <div className="absolute -top-8 left-1/2 w-0.5 h-8 bg-slate-600"></div>
           
           {/* Branch A */}
           <div className="flex flex-col items-center flex-1 relative">
              <div className="absolute -top-8 left-1/2 w-[52%] h-8 border-t-2 border-l-2 border-slate-600 rounded-tl-xl -translate-x-full"></div>
              <div className={`px-3 py-1 rounded-full text-xs font-bold mb-4 border z-10 ${node.type === 'split_random' ? 'bg-pink-500/20 text-pink-400 border-pink-500/30' : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'}`}>
                {node.type === 'split_random' ? 'Variant A (50%)' : 'YES'}
              </div>
              
              {node.branches?.true.map((child) => (
                <React.Fragment key={child.id}>
                  <FlowStep node={child} onSelect={onSelect} onAdd={onAdd} selectedNodeId={selectedNodeId} />
                </React.Fragment>
              ))}
              
              <AddNodeButton onClick={() => onAdd(node.id, 'true')} />
           </div>

           {/* Branch B */}
           <div className="flex flex-col items-center flex-1 relative">
              <div className="absolute -top-8 right-1/2 w-[52%] h-8 border-t-2 border-r-2 border-slate-600 rounded-tr-xl -translate-x-full"></div>
              <div className={`px-3 py-1 rounded-full text-xs font-bold mb-4 border z-10 ${node.type === 'split_random' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 'bg-red-500/20 text-red-400 border-red-500/30'}`}>
                {node.type === 'split_random' ? 'Variant B (50%)' : 'NO'}
              </div>
              
              {node.branches?.false.map((child) => (
                 <React.Fragment key={child.id}>
                   <FlowStep node={child} onSelect={onSelect} onAdd={onAdd} selectedNodeId={selectedNodeId} />
                 </React.Fragment>
              ))}

              <AddNodeButton onClick={() => onAdd(node.id, 'false')} />
           </div>
        </div>
      ) : (
        <>
          <div className="h-8 w-0.5 bg-slate-600"></div>
          {node.children && node.children.length > 0 ? (
            node.children.map(child => (
              <FlowStep key={child.id} node={child} onSelect={onSelect} onAdd={onAdd} selectedNodeId={selectedNodeId} />
            ))
          ) : (
            <AddNodeButton onClick={() => onAdd(node.id)} />
          )}
        </>
      )}
    </div>
  );
};

export const EmailBuilder: React.FC = () => {
  const [mode, setMode] = useState<'flow' | 'design'>('flow');
  const [sidebarTab, setSidebarTab] = useState<'triggers' | 'templates'>('triggers');
  const [searchTerm, setSearchTerm] = useState('');
  const [zoom, setZoom] = useState(1);
  
  // Flow State
  const [flowNodes, setFlowNodes] = useState<FlowNode[]>([
    { 
      id: 'root', 
      type: 'trigger', 
      title: 'Cart Abandoned', 
      description: 'Wait 1 hour after checkout exit',
      children: [
        { 
          id: 'delay_1', 
          type: 'delay', 
          title: 'Wait 1 Hour', 
          description: 'Optimized time',
          children: [
            {
              id: 'split_1',
              type: 'split_random',
              title: 'A/B Test Subject Line',
              description: '50/50 Split',
              branches: {
                true: [
                   { id: 'email_a', type: 'action_email', title: 'Email A (Urgent)', description: '"Items expiring soon"', children: [] }
                ],
                false: [
                   { id: 'email_b', type: 'action_email', title: 'Email B (Helpful)', description: '"Did you need help?"', children: [] }
                ]
              }
            }
          ]
        }
      ]
    }
  ]);
  
  const [selectedNode, setSelectedNode] = useState<FlowNode | null>(null);
  const [showNodePicker, setShowNodePicker] = useState<{parentId: string, branch?: 'true'|'false'} | null>(null);

  // Designer State
  const [template, setTemplate] = useState<EmailTemplate>(INITIAL_TEMPLATE);
  const [selectedElement, setSelectedElement] = useState<EmailElement | null>(null);

  // --- HELPERS ---

  const updateNodeInTree = (nodes: FlowNode[], nodeId: string, updates: Partial<FlowNode>): FlowNode[] => {
    return nodes.map(node => {
      if (node.id === nodeId) {
        return { ...node, ...updates };
      }
      if (node.children) {
        node.children = updateNodeInTree(node.children, nodeId, updates);
      }
      if (node.branches) {
        node.branches.true = updateNodeInTree(node.branches.true, nodeId, updates);
        node.branches.false = updateNodeInTree(node.branches.false, nodeId, updates);
      }
      return node;
    });
  };

  const addNodeToTree = (nodes: FlowNode[], parentId: string, newNode: FlowNode, branch?: 'true'|'false'): FlowNode[] => {
    return nodes.map(node => {
      if (node.id === parentId) {
        if ((node.type === 'condition' || node.type === 'split_random') && branch) {
          const targetBranch = node.branches![branch];
          return {
            ...node,
            branches: {
              ...node.branches!,
              [branch]: [...targetBranch, newNode]
            }
          };
        } else {
           return { ...node, children: [...(node.children || []), newNode] };
        }
      }
      
      if (node.children) node.children = addNodeToTree(node.children, parentId, newNode, branch);
      if (node.branches) {
        node.branches.true = addNodeToTree(node.branches.true, parentId, newNode, branch);
        node.branches.false = addNodeToTree(node.branches.false, parentId, newNode, branch);
      }
      return node;
    });
  };

  const handleAddNode = (type: NodeType) => {
    if (!showNodePicker) return;

    const titles: Record<NodeType, string> = {
      trigger: 'Trigger',
      action_email: 'Send Email',
      action_sms: 'Send SMS',
      delay: 'Time Delay',
      condition: 'Conditional Split',
      split_random: 'A/B Split',
      action_tag: 'Add Tag',
      action_notification: 'Internal Alert',
      split: 'Split'
    };

    const newNode: FlowNode = {
      id: Date.now().toString(),
      type,
      title: titles[type],
      description: 'Click to configure',
      children: [],
      ...((type === 'condition' || type === 'split_random') ? { branches: { true: [], false: [] } } : {})
    };

    setFlowNodes(prev => addNodeToTree(prev, showNodePicker.parentId, newNode, showNodePicker.branch));
    setShowNodePicker(null);
    setSelectedNode(newNode);
  };

  const handleEditContent = () => {
    if (selectedNode?.type === 'action_email') {
      setMode('design');
    }
  };

  return (
    <div className="h-[calc(100vh-100px)] flex flex-col">
      {/* Toolbar */}
      <div className="flex justify-between items-center mb-4 flex-shrink-0">
        <div className="flex items-center gap-3">
           <h1 className="text-2xl font-bold text-white">
             {mode === 'flow' ? 'Automation Flow' : 'Email Designer'}
           </h1>
           {mode === 'design' && (
             <button onClick={() => setMode('flow')} className="text-slate-400 hover:text-white text-sm flex items-center gap-1">
               <ChevronDown className="w-4 h-4 rotate-90" /> Back to Flow
             </button>
           )}
        </div>
        
        <div className="flex items-center gap-4">
            {mode === 'design' && (
              <div className="flex gap-2">
                <button className="px-4 py-2 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-700">Preview</button>
                <button onClick={() => setMode('flow')} className="px-4 py-2 bg-brand-600 text-white rounded-lg text-sm font-bold hover:bg-brand-500 flex items-center gap-2">
                  <Save className="w-4 h-4" /> Save & Close
                </button>
              </div>
            )}
            
            {mode === 'flow' && (
              <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
                  <button className="px-4 py-2 rounded text-sm font-medium bg-brand-600 text-white flex items-center gap-2">
                    <Workflow className="w-4 h-4" /> Active
                  </button>
                  <button className="px-4 py-2 rounded text-sm font-medium text-slate-400 hover:text-white flex items-center gap-2">
                    <Clock className="w-4 h-4" /> History
                  </button>
              </div>
            )}
        </div>
      </div>

      {/* --- FLOW MODE --- */}
      {mode === 'flow' && (
        <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl flex overflow-hidden relative">
           
           {/* Left Sidebar: Library */}
           <div className="w-80 border-r border-slate-800 flex flex-col bg-slate-950 z-10">
              <div className="p-4 border-b border-slate-800">
                  <div className="mb-3 relative">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500"/>
                      <input 
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg py-2 pl-9 text-sm text-white placeholder-slate-500 focus:border-brand-500 outline-none" 
                        placeholder="Search triggers..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                  </div>
                  <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
                      <button onClick={() => setSidebarTab('triggers')} className={`flex-1 py-1.5 text-xs font-medium rounded flex justify-center items-center gap-1 ${sidebarTab === 'triggers' ? 'bg-brand-600 text-white' : 'text-slate-400'}`}>
                        <Zap className="w-3 h-3" /> Triggers
                      </button>
                      <button onClick={() => setSidebarTab('templates')} className={`flex-1 py-1.5 text-xs font-medium rounded flex justify-center items-center gap-1 ${sidebarTab === 'templates' ? 'bg-brand-600 text-white' : 'text-slate-400'}`}>
                        <Layers className="w-3 h-3" /> Flows
                      </button>
                  </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-6">
                 {(sidebarTab === 'triggers' ? TRIGGER_CATEGORIES : WORKFLOW_TEMPLATES).map((cat, idx) => (
                    <div key={idx}>
                        <h3 className="text-xs font-bold text-brand-500 uppercase mb-3">{cat.title}</h3>
                        <div className="space-y-2">
                            {cat.items.filter(i => i.toLowerCase().includes(searchTerm.toLowerCase())).map(item => (
                                <div key={item} className="p-3 bg-slate-900 border border-slate-800 rounded text-sm text-slate-300 hover:border-brand-500 hover:text-white cursor-grab transition-all group flex items-center gap-2">
                                    <div className="w-1.5 h-1.5 rounded-full bg-slate-700 group-hover:bg-brand-500"></div>
                                    {item}
                                </div>
                            ))}
                        </div>
                    </div>
                 ))}
              </div>
           </div>

           {/* Center: Canvas */}
           <div 
             className="flex-1 overflow-hidden relative bg-slate-900"
             onClick={() => setSelectedNode(null)}
           >
              {/* Zoom Controls */}
              <div className="absolute bottom-6 left-6 z-20 flex flex-col gap-2 bg-slate-900 border border-slate-700 rounded-lg p-2 shadow-xl">
                  <button onClick={(e) => { e.stopPropagation(); setZoom(z => Math.min(z + 0.1, 2)); }} className="p-2 hover:bg-slate-800 rounded text-slate-300"><ZoomIn className="w-5 h-5"/></button>
                  <button onClick={(e) => { e.stopPropagation(); setZoom(1); }} className="p-2 hover:bg-slate-800 rounded text-slate-300 text-xs font-bold">{Math.round(zoom * 100)}%</button>
                  <button onClick={(e) => { e.stopPropagation(); setZoom(z => Math.max(z - 0.1, 0.5)); }} className="p-2 hover:bg-slate-800 rounded text-slate-300"><ZoomOut className="w-5 h-5"/></button>
              </div>

              <div 
                className="h-full w-full overflow-auto p-10 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:20px_20px] custom-scrollbar"
              >
                  <div 
                    className="min-w-max pb-20 flex justify-center transition-transform duration-200 origin-top"
                    style={{ transform: `scale(${zoom})` }}
                  >
                      {flowNodes.map(node => (
                        <FlowStep 
                          key={node.id} 
                          node={node} 
                          onSelect={setSelectedNode} 
                          onAdd={(parentId, branch) => setShowNodePicker({parentId, branch})}
                          selectedNodeId={selectedNode?.id || null}
                        />
                      ))}
                  </div>
              </div>
           </div>

           {/* Right Sidebar: Config Panel */}
           {selectedNode && (
             <div className="w-80 border-l border-slate-800 bg-slate-950 flex flex-col absolute right-0 top-0 bottom-0 shadow-2xl animate-slide-in-right z-20">
                <div className="p-4 border-b border-slate-800 flex justify-between items-center">
                    <h3 className="font-bold text-white">Configure Step</h3>
                    <button onClick={() => setSelectedNode(null)} className="text-slate-500 hover:text-white"><X className="w-5 h-5"/></button>
                </div>
                
                <div className="flex-1 p-6 space-y-6 overflow-y-auto">
                    <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1 uppercase">Step Name</label>
                        <input 
                          type="text" 
                          value={selectedNode.title} 
                          onChange={(e) => {
                              setFlowNodes(prev => updateNodeInTree(prev, selectedNode.id, { title: e.target.value }));
                              setSelectedNode({...selectedNode, title: e.target.value});
                          }}
                          className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-brand-500 outline-none"
                        />
                    </div>

                    {selectedNode.type === 'action_email' && (
                        <>
                           <div>
                              <label className="block text-xs font-medium text-slate-400 mb-1 uppercase">Subject Line</label>
                              <input 
                                className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-brand-500 outline-none" 
                                placeholder="Enter subject..."
                                defaultValue="We miss you!"
                              />
                           </div>
                           <button 
                             onClick={handleEditContent}
                             className="w-full py-3 bg-brand-600 hover:bg-brand-500 text-white rounded-lg font-bold shadow-lg shadow-brand-500/20 flex items-center justify-center gap-2"
                           >
                               <Palette className="w-4 h-4" /> Edit Email Content
                           </button>
                        </>
                    )}

                    {selectedNode.type === 'delay' && (
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-medium text-slate-400 mb-1 uppercase">Duration</label>
                                <input type="number" className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white" defaultValue="1" />
                            </div>
                            <div>
                                <label className="block text-xs font-medium text-slate-400 mb-1 uppercase">Unit</label>
                                <select className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white">
                                    <option>Hours</option>
                                    <option>Days</option>
                                    <option>Minutes</option>
                                </select>
                            </div>
                        </div>
                    )}

                    {selectedNode.type === 'condition' && (
                        <div className="p-4 bg-slate-900 rounded-lg border border-slate-800">
                            <p className="text-sm text-white font-medium mb-2">If Customer...</p>
                            <select className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm mb-2">
                                <option>Has purchased product</option>
                                <option>Cart value > $100</option>
                                <option>Is in VIP segment</option>
                            </select>
                        </div>
                    )}

                    {selectedNode.type === 'split_random' && (
                        <div className="p-4 bg-slate-900 rounded-lg border border-slate-800">
                            <p className="text-sm text-white font-medium mb-3">Split Traffic</p>
                            <div className="flex items-center justify-between text-sm text-slate-400 mb-1">
                              <span>Variant A</span>
                              <span>50%</span>
                            </div>
                            <div className="w-full bg-slate-700 h-2 rounded-full mb-4 overflow-hidden">
                                <div className="bg-pink-500 h-full w-1/2"></div>
                            </div>
                            <p className="text-xs text-slate-500">Traffic will be randomly divided 50/50 between the two paths.</p>
                        </div>
                    )}

                    {selectedNode.type === 'action_tag' && (
                        <div>
                            <label className="block text-xs font-medium text-slate-400 mb-1 uppercase">Tag Name</label>
                            <input 
                              type="text" 
                              className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-brand-500 outline-none" 
                              placeholder="e.g. VIP, Churned, Engaged" 
                            />
                            <div className="mt-2 flex gap-2 flex-wrap">
                              {['VIP', 'New', 'Churned'].map(t => (
                                <span key={t} className="text-xs bg-slate-800 border border-slate-700 px-2 py-1 rounded text-slate-400 cursor-pointer hover:text-white">{t}</span>
                              ))}
                            </div>
                        </div>
                    )}

                    {selectedNode.type === 'action_notification' && (
                        <div>
                            <label className="block text-xs font-medium text-slate-400 mb-1 uppercase">Message to Team</label>
                            <textarea 
                              className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white focus:border-brand-500 outline-none h-24 resize-none" 
                              placeholder="e.g. High value cart abandoned by VIP customer." 
                            />
                        </div>
                    )}
                    
                    <div className="pt-6 border-t border-slate-800">
                        <button className="text-red-400 hover:text-red-300 text-sm flex items-center gap-2 w-full justify-center p-2 hover:bg-slate-900 rounded">
                            <Trash2 className="w-4 h-4" /> Delete Step
                        </button>
                    </div>
                </div>
             </div>
           )}

           {/* Node Picker Modal */}
           {showNodePicker && (
              <div className="absolute inset-0 bg-black/60 z-30 flex items-center justify-center backdrop-blur-sm">
                  <div className="bg-slate-900 border border-slate-700 rounded-xl p-0 w-[500px] shadow-2xl overflow-hidden">
                      <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900">
                          <h3 className="font-bold text-white">Add Step</h3>
                          <button onClick={() => setShowNodePicker(null)} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
                      </div>
                      <div className="p-6 grid grid-cols-1 gap-6 max-h-[600px] overflow-y-auto">
                          
                          {/* Messaging Section */}
                          <div>
                             <h4 className="text-xs font-bold text-slate-500 uppercase mb-3">Messaging</h4>
                             <div className="grid grid-cols-2 gap-3">
                                {[
                                    { type: 'action_email', icon: Mail, label: 'Send Email', color: 'text-blue-400' },
                                    { type: 'action_sms', icon: Smartphone, label: 'Send SMS', color: 'text-green-400' },
                                    { type: 'action_notification', icon: Bell, label: 'Internal Alert', color: 'text-red-400' },
                                ].map(opt => (
                                    <button 
                                      key={opt.type} 
                                      onClick={() => handleAddNode(opt.type as NodeType)}
                                      className="p-3 bg-slate-800 border border-slate-700 rounded-lg hover:border-brand-500 hover:bg-slate-800/80 flex items-center gap-3 transition-all text-left group"
                                    >
                                        <div className={`p-2 rounded bg-slate-900 group-hover:bg-slate-900/80 ${opt.color}`}>
                                           <opt.icon className="w-5 h-5" />
                                        </div>
                                        <span className="text-sm text-white font-medium">{opt.label}</span>
                                    </button>
                                ))}
                             </div>
                          </div>

                          {/* Logic Section */}
                          <div>
                             <h4 className="text-xs font-bold text-slate-500 uppercase mb-3">Logic & Flow</h4>
                             <div className="grid grid-cols-2 gap-3">
                                {[
                                    { type: 'delay', icon: Clock, label: 'Time Delay', color: 'text-orange-400' },
                                    { type: 'condition', icon: GitBranch, label: 'Conditional Split', color: 'text-purple-400' },
                                    { type: 'split_random', icon: Percent, label: 'A/B Split', color: 'text-pink-400' },
                                ].map(opt => (
                                    <button 
                                      key={opt.type} 
                                      onClick={() => handleAddNode(opt.type as NodeType)}
                                      className="p-3 bg-slate-800 border border-slate-700 rounded-lg hover:border-brand-500 hover:bg-slate-800/80 flex items-center gap-3 transition-all text-left group"
                                    >
                                        <div className={`p-2 rounded bg-slate-900 group-hover:bg-slate-900/80 ${opt.color}`}>
                                           <opt.icon className="w-5 h-5" />
                                        </div>
                                        <span className="text-sm text-white font-medium">{opt.label}</span>
                                    </button>
                                ))}
                             </div>
                          </div>

                          {/* CRM Section */}
                          <div>
                             <h4 className="text-xs font-bold text-slate-500 uppercase mb-3">CRM Actions</h4>
                             <div className="grid grid-cols-2 gap-3">
                                {[
                                    { type: 'action_tag', icon: Tag, label: 'Add/Remove Tag', color: 'text-indigo-400' },
                                ].map(opt => (
                                    <button 
                                      key={opt.type} 
                                      onClick={() => handleAddNode(opt.type as NodeType)}
                                      className="p-3 bg-slate-800 border border-slate-700 rounded-lg hover:border-brand-500 hover:bg-slate-800/80 flex items-center gap-3 transition-all text-left group"
                                    >
                                        <div className={`p-2 rounded bg-slate-900 group-hover:bg-slate-900/80 ${opt.color}`}>
                                           <opt.icon className="w-5 h-5" />
                                        </div>
                                        <span className="text-sm text-white font-medium">{opt.label}</span>
                                    </button>
                                ))}
                             </div>
                          </div>

                      </div>
                  </div>
              </div>
           )}
        </div>
      )}

      {/* --- DESIGNER MODE --- */}
      {mode === 'design' && (
        <div className="flex-1 flex bg-slate-200/5 border border-slate-800 rounded-xl overflow-hidden relative">
          {/* Left: Components */}
          <div className="w-64 bg-slate-950 border-r border-slate-800 p-4 flex flex-col gap-4">
              <h3 className="text-xs font-bold text-slate-500 uppercase">Elements</h3>
              <div className="grid grid-cols-2 gap-2">
                  {[
                      { icon: Type, label: 'Text' },
                      { icon: ImageIcon, label: 'Image' },
                      { icon: MousePointer, label: 'Button' },
                      { icon: ShoppingBag, label: 'Product' },
                      { icon: Layout, label: 'Spacer' },
                  ].map(el => (
                      <div key={el.label} className="p-3 bg-slate-900 border border-slate-800 rounded flex flex-col items-center gap-2 cursor-grab hover:border-brand-500 transition-colors">
                          <el.icon className="w-5 h-5 text-slate-400" />
                          <span className="text-xs text-slate-300">{el.label}</span>
                      </div>
                  ))}
              </div>
              <div className="mt-auto p-4 bg-slate-900 rounded-xl border border-slate-800">
                  <h4 className="text-white font-bold text-sm mb-2 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-brand-500" /> AI Magic
                  </h4>
                  <p className="text-xs text-slate-400 mb-3">Select an element to rewrite copy or generate images.</p>
              </div>
          </div>

          {/* Center: Canvas */}
          <div className="flex-1 bg-[#e2e8f0] overflow-y-auto flex justify-center p-8">
             <div className="w-[600px] min-h-[800px] bg-white shadow-2xl rounded-lg flex flex-col overflow-hidden">
                {/* Email Header */}
                <div className="h-2 bg-brand-500 w-full"></div>
                <div className="p-8 flex-1 space-y-4">
                    {template.elements.map(el => (
                        <div 
                          key={el.id} 
                          className={`p-2 border-2 border-transparent hover:border-brand-500/30 cursor-pointer relative group ${selectedElement?.id === el.id ? '!border-brand-500' : ''}`} 
                          onClick={() => setSelectedElement(el)}
                        >
                            {el.type === 'text' && <div style={el.style}>{el.content}</div>}
                            {el.type === 'image' && <img src={el.src} className="w-full rounded" alt="" />}
                            {el.type === 'button' && <div className="text-center"><span style={el.style}>{el.content}</span></div>}
                            
                            <div className="absolute top-0 right-0 bg-brand-500 text-white p-1 rounded-bl opacity-0 group-hover:opacity-100 transition-opacity">
                                <Settings className="w-3 h-3" />
                            </div>
                        </div>
                    ))}
                </div>
                {/* Email Footer */}
                <div className="p-8 bg-slate-50 text-center text-xs text-slate-500">
                    <p>© 2023 BuzzBit X. All rights reserved.</p>
                    <p className="mt-2 underline">Unsubscribe</p>
                </div>
             </div>
          </div>

          {/* Right: Properties */}
          <div className="w-72 bg-slate-950 border-l border-slate-800 p-4">
             <h3 className="font-bold text-white mb-4">Properties</h3>
             {selectedElement ? (
                 <div className="space-y-4">
                     <div className="p-3 bg-slate-900 border border-slate-800 rounded">
                         <p className="text-xs text-slate-500 uppercase mb-1">Content</p>
                         {selectedElement.type === 'text' ? (
                             <textarea 
                               className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm h-32"
                               value={selectedElement.content}
                               onChange={(e) => {
                                   const newContent = e.target.value;
                                   setTemplate({
                                       ...template,
                                       elements: template.elements.map(el => el.id === selectedElement.id ? {...el, content: newContent} : el)
                                   });
                                   setSelectedElement({...selectedElement, content: newContent});
                               }}
                             />
                         ) : (
                             <input className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white text-sm" value={selectedElement.content} onChange={() => {}} />
                         )}
                     </div>

                     {selectedElement.type === 'text' && (
                         <button 
                             onClick={async () => {
                                 const opt = await optimizeEmailContent(selectedElement.content, 'body');
                                 setTemplate({
                                     ...template, 
                                     elements: template.elements.map(e => e.id === selectedElement.id ? {...e, content: opt} : e)
                                 });
                                 setSelectedElement({...selectedElement, content: opt});
                             }}
                             className="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white rounded text-sm flex items-center justify-center gap-2 font-medium transition-colors"
                         >
                             <Sparkles className="w-4 h-4" /> Rewrite with AI
                         </button>
                     )}

                     <div className="grid grid-cols-2 gap-2">
                         <div className="p-2 bg-slate-900 rounded border border-slate-800">
                             <p className="text-[10px] text-slate-500 uppercase">Padding</p>
                             <input type="range" className="w-full accent-brand-500 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer mt-2" />
                         </div>
                         <div className="p-2 bg-slate-900 rounded border border-slate-800">
                             <p className="text-[10px] text-slate-500 uppercase">Size</p>
                             <input type="range" className="w-full accent-brand-500 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer mt-2" />
                         </div>
                     </div>
                 </div>
             ) : (
                 <div className="flex flex-col items-center justify-center h-40 text-slate-500 text-sm">
                     <MousePointer className="w-8 h-8 mb-2 opacity-20" />
                     Select an element to edit
                 </div>
             )}
          </div>
        </div>
      )}
    </div>
  );
};

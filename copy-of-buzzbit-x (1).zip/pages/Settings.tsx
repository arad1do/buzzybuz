
import React, { useState } from 'react';
import { User, Users, CreditCard, Lock, Globe, Bell, Save, Shield } from 'lucide-react';
import { TeamMember } from '../types';

const MOCK_TEAM: TeamMember[] = [
  { id: '1', name: 'John Doe', role: 'admin', email: 'john@buzzbit.com', status: 'active' },
  { id: '2', name: 'Sarah Smith', role: 'editor', email: 'sarah@buzzbit.com', status: 'active' },
  { id: '3', name: 'Mike Ross', role: 'viewer', email: 'mike@buzzbit.com', status: 'invited' },
];

export const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'general' | 'team' | 'billing' | 'security' | 'notifications'>('general');
  const [storeName, setStoreName] = useState('BuzzBit Demo Store');
  const [currency, setCurrency] = useState('USD');
  const [team, setTeam] = useState(MOCK_TEAM);

  const renderGeneral = () => (
      <div className="max-w-2xl space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">Store Profile</h3>
              <div className="space-y-4">
                  <div>
                      <label className="block text-sm font-medium text-slate-300 mb-1">Store Name</label>
                      <input 
                        type="text" 
                        value={storeName}
                        onChange={(e) => setStoreName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white focus:border-brand-500 outline-none"
                      />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                      <div>
                          <label className="block text-sm font-medium text-slate-300 mb-1">Currency</label>
                          <select 
                            value={currency}
                            onChange={(e) => setCurrency(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white focus:border-brand-500 outline-none"
                          >
                              <option value="USD">USD ($)</option>
                              <option value="EUR">EUR (€)</option>
                              <option value="GBP">GBP (£)</option>
                          </select>
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-slate-300 mb-1">Timezone</label>
                          <select className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white focus:border-brand-500 outline-none">
                              <option value="UTC">UTC (GMT+0)</option>
                              <option value="EST">EST (GMT-5)</option>
                              <option value="PST">PST (GMT-8)</option>
                          </select>
                      </div>
                  </div>
              </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">AI Configuration</h3>
              <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-950 rounded-lg border border-slate-800">
                      <div>
                          <h4 className="font-medium text-white text-sm">Auto-Optimization</h4>
                          <p className="text-xs text-slate-400">Allow AI to automatically adjust send times.</p>
                      </div>
                      <div className="relative inline-block w-10 h-6 rounded-full bg-brand-600 cursor-pointer">
                          <span className="absolute left-5 top-1 bg-white w-4 h-4 rounded-full transition-all"></span>
                      </div>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-950 rounded-lg border border-slate-800">
                      <div>
                          <h4 className="font-medium text-white text-sm">Smart Content Generation</h4>
                          <p className="text-xs text-slate-400">Use Gemini 2.5 Flash for drafting emails.</p>
                      </div>
                      <div className="relative inline-block w-10 h-6 rounded-full bg-brand-600 cursor-pointer">
                          <span className="absolute left-5 top-1 bg-white w-4 h-4 rounded-full transition-all"></span>
                      </div>
                  </div>
              </div>
          </div>

          <div className="flex justify-end">
              <button className="px-6 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-lg font-medium transition-colors flex items-center gap-2">
                  <Save className="w-4 h-4" /> Save Changes
              </button>
          </div>
      </div>
  );

  const renderTeam = () => (
      <div className="max-w-4xl">
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="p-6 border-b border-slate-800 flex justify-between items-center">
                  <div>
                      <h3 className="text-lg font-bold text-white">Team Members</h3>
                      <p className="text-sm text-slate-400">Manage access and roles.</p>
                  </div>
                  <button className="bg-white text-slate-900 px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors">
                      Invite Member
                  </button>
              </div>
              <table className="w-full text-left text-sm text-slate-400">
                  <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium">
                      <tr>
                          <th className="px-6 py-4">User</th>
                          <th className="px-6 py-4">Role</th>
                          <th className="px-6 py-4">Status</th>
                          <th className="px-6 py-4 text-right">Action</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                      {team.map(member => (
                          <tr key={member.id} className="hover:bg-slate-800/30 transition-colors">
                              <td className="px-6 py-4 flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-white font-bold text-xs">
                                      {member.name.charAt(0)}
                                  </div>
                                  <div>
                                      <p className="text-white font-medium">{member.name}</p>
                                      <p className="text-xs text-slate-500">{member.email}</p>
                                  </div>
                              </td>
                              <td className="px-6 py-4 capitalize">{member.role}</td>
                              <td className="px-6 py-4">
                                  <span className={`px-2 py-1 rounded-full text-xs capitalize border ${
                                      member.status === 'active' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
                                  }`}>
                                      {member.status}
                                  </span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                  <button className="text-slate-500 hover:text-brand-400 text-xs underline">Edit</button>
                              </td>
                          </tr>
                      ))}
                  </tbody>
              </table>
          </div>
      </div>
  );

  const renderBilling = () => (
      <div className="max-w-2xl space-y-6">
          <div className="bg-gradient-to-br from-brand-900 to-slate-900 border border-brand-500/30 rounded-xl p-6 relative overflow-hidden">
              <div className="relative z-10">
                  <div className="flex justify-between items-start mb-4">
                      <div>
                          <p className="text-brand-300 text-sm font-bold uppercase">Current Plan</p>
                          <h3 className="text-2xl font-bold text-white">Growth Plan</h3>
                      </div>
                      <span className="bg-white/10 text-white px-3 py-1 rounded-full text-xs border border-white/20">Active</span>
                  </div>
                  <p className="text-slate-300 text-sm mb-6">You have <strong>34,500</strong> contacts remaining in this billing cycle.</p>
                  <div className="flex gap-3">
                      <button className="bg-white text-brand-900 px-4 py-2 rounded-lg font-bold text-sm hover:bg-slate-100 transition-colors">Manage Subscription</button>
                      <button className="text-white px-4 py-2 rounded-lg font-medium text-sm hover:bg-white/10 transition-colors">View Invoices</button>
                  </div>
              </div>
              <div className="absolute top-0 right-0 w-64 h-64 bg-brand-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">Payment Method</h3>
              <div className="flex items-center justify-between p-4 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-800 rounded text-white">
                          <CreditCard className="w-6 h-6" />
                      </div>
                      <div>
                          <p className="text-sm font-bold text-white">Visa ending in 4242</p>
                          <p className="text-xs text-slate-500">Expires 12/2025</p>
                      </div>
                  </div>
                  <button className="text-sm text-brand-400 hover:underline">Update</button>
              </div>
          </div>
      </div>
  );

  return (
    <div className="h-[calc(100vh-100px)] flex flex-col md:flex-row gap-6">
       {/* Sidebar Navigation */}
       <div className="w-full md:w-64 bg-slate-900 border border-slate-800 rounded-xl p-2 flex md:flex-col gap-1 h-fit">
           {[
               { id: 'general', label: 'General', icon: Globe },
               { id: 'team', label: 'Team Members', icon: Users },
               { id: 'billing', label: 'Billing & Plans', icon: CreditCard },
               { id: 'security', label: 'Security', icon: Lock },
               { id: 'notifications', label: 'Notifications', icon: Bell },
           ].map(item => (
               <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                      activeTab === item.id ? 'bg-brand-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
               >
                   <item.icon className="w-4 h-4" />
                   {item.label}
               </button>
           ))}
       </div>

       {/* Content Area */}
       <div className="flex-1 overflow-y-auto">
           {activeTab === 'general' && renderGeneral()}
           {activeTab === 'team' && renderTeam()}
           {activeTab === 'billing' && renderBilling()}
           {activeTab === 'security' && (
               <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center">
                   <Shield className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                   <h3 className="text-xl font-bold text-white">Security Settings</h3>
                   <p className="text-slate-400">2FA and Audit Logs are enabled by default for Enterprise plans.</p>
               </div>
           )}
           {activeTab === 'notifications' && (
               <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center">
                   <Bell className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                   <h3 className="text-xl font-bold text-white">Notification Preferences</h3>
                   <p className="text-slate-400">Configure email and push alerts here.</p>
               </div>
           )}
       </div>
    </div>
  );
};

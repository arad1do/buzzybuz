
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Zap, Mail, Lock, User, ArrowRight, Github, Chrome } from 'lucide-react';

export const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate auth
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Left Panel - Visual */}
      <div className="hidden lg:flex flex-1 bg-slate-900 relative overflow-hidden items-center justify-center p-12">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop')] bg-cover bg-center opacity-10"></div>
        <div className="relative z-10 max-w-lg">
          <div className="mb-8 flex items-center gap-3">
            <Zap className="w-12 h-12 text-brand-500" />
            <span className="text-4xl font-bold text-white">BuzzBit X</span>
          </div>
          <h2 className="text-3xl font-bold text-white mb-6">
            Command your e-commerce empire with AI.
          </h2>
          <div className="space-y-4">
            <div className="flex items-center gap-4 text-slate-300">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-500"><ArrowRight className="w-4 h-4" /></div>
              <p>Generate marketing campaigns in seconds</p>
            </div>
            <div className="flex items-center gap-4 text-slate-300">
              <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-500"><ArrowRight className="w-4 h-4" /></div>
              <p>Automate customer support across all channels</p>
            </div>
            <div className="flex items-center gap-4 text-slate-300">
              <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-500"><ArrowRight className="w-4 h-4" /></div>
              <p>Predict revenue and inventory needs</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Form */}
      <div className="flex-1 flex items-center justify-center p-6 relative">
        <Link to="/landing" className="absolute top-8 right-8 text-slate-500 hover:text-white transition-colors text-sm">Back to Home</Link>
        
        <div className="w-full max-w-md">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-white mb-2">{isLogin ? 'Welcome back' : 'Create an account'}</h2>
            <p className="text-slate-400">
              {isLogin ? 'Enter your details to access your dashboard.' : 'Start your 14-day free trial today.'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input 
                  type="text" 
                  placeholder="Full Name"
                  className="w-full bg-slate-900 border border-slate-800 text-white px-10 py-3 rounded-lg focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none transition-all"
                />
              </div>
            )}
            
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input 
                type="email" 
                placeholder="Email Address"
                className="w-full bg-slate-900 border border-slate-800 text-white px-10 py-3 rounded-lg focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none transition-all"
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input 
                type="password" 
                placeholder="Password"
                className="w-full bg-slate-900 border border-slate-800 text-white px-10 py-3 rounded-lg focus:border-brand-500 focus:ring-1 focus:ring-brand-500 outline-none transition-all"
              />
            </div>

            <button className="w-full bg-brand-600 hover:bg-brand-500 text-white py-3 rounded-lg font-medium transition-colors shadow-lg shadow-brand-500/20 mt-2">
              {isLogin ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-800"></div></div>
            <div className="relative flex justify-center text-sm"><span className="px-2 bg-slate-950 text-slate-500">Or continue with</span></div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg border border-slate-800 transition-colors">
              <Github className="w-5 h-5" /> Github
            </button>
            <button className="flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg border border-slate-800 transition-colors">
              <Chrome className="w-5 h-5 text-blue-500" /> Google
            </button>
          </div>

          <div className="text-center mt-8 text-sm text-slate-400">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button onClick={() => setIsLogin(!isLogin)} className="text-brand-500 hover:text-brand-400 font-medium">
              {isLogin ? 'Sign up' : 'Log in'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

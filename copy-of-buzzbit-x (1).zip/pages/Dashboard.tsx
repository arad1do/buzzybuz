
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';
import { DollarSign, Users, MousePointer, ShoppingBag, Activity, Sparkles, AlertTriangle, TrendingUp, Megaphone } from 'lucide-react';
import { StatsCard } from '../components/StatsCard';
import { KPI } from '../types';

const revenueData = [
  { name: 'Mon', revenue: 4000, orders: 24 },
  { name: 'Tue', revenue: 3000, orders: 18 },
  { name: 'Wed', revenue: 2000, orders: 12 },
  { name: 'Thu', revenue: 2780, orders: 30 },
  { name: 'Fri', revenue: 1890, orders: 20 },
  { name: 'Sat', revenue: 2390, orders: 25 },
  { name: 'Sun', revenue: 3490, orders: 35 },
];

const adsData = [
  { name: 'Mon', spend: 400, roas: 3.2 },
  { name: 'Tue', spend: 300, roas: 2.8 },
  { name: 'Wed', spend: 550, roas: 4.1 },
  { name: 'Thu', spend: 450, roas: 3.5 },
  { name: 'Fri', spend: 600, roas: 3.8 },
  { name: 'Sat', spend: 800, roas: 4.5 },
  { name: 'Sun', spend: 750, roas: 4.2 },
];

const stats: KPI[] = [
  { label: 'Total Revenue', value: '$124,592', change: 12.5, trend: 'up' },
  { label: 'Active Customers', value: '8,549', change: 8.2, trend: 'up' },
  { label: 'Avg. Order Value', value: '$142.50', change: -2.4, trend: 'down' },
  { label: 'Conversion Rate', value: '3.24%', change: 4.1, trend: 'up' },
];

export const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Overview</h1>
          <p className="text-slate-400">Welcome back, here's what's happening today.</p>
        </div>
        <div className="flex gap-3">
            <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-medium transition-colors">
                Last 7 Days
            </button>
            <button className="px-4 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-lg text-sm font-medium transition-colors shadow-lg shadow-brand-500/20">
                Download Report
            </button>
        </div>
      </div>

      {/* AI Intelligence Feed */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-900 border border-brand-500/30 rounded-xl p-1 shadow-lg relative overflow-hidden">
         <div className="absolute top-0 left-0 w-1 h-full bg-brand-500"></div>
         <div className="bg-slate-900/90 rounded-lg p-4 flex flex-col md:flex-row items-start md:items-center gap-4">
            <div className="p-3 bg-brand-500/10 rounded-full">
               <Sparkles className="w-6 h-6 text-brand-500 animate-pulse" />
            </div>
            <div className="flex-1">
               <h3 className="font-bold text-white flex items-center gap-2">
                  BuzzBit Intelligence
                  <span className="text-[10px] bg-brand-500 text-white px-1.5 py-0.5 rounded font-medium">LIVE</span>
               </h3>
               <p className="text-sm text-slate-400">
                  3 high-priority actions detected by AI:
               </p>
            </div>
            <div className="flex flex-col gap-2 w-full md:w-auto">
               <div className="flex items-center gap-2 text-sm text-slate-300 bg-slate-800/50 px-3 py-1.5 rounded border border-slate-700">
                  <AlertTriangle className="w-4 h-4 text-yellow-500" />
                  <span>Stock Low: "Premium Leather Bag" (Only 2 left)</span>
                  <button className="text-brand-400 text-xs hover:underline ml-auto">Restock</button>
               </div>
               <div className="flex items-center gap-2 text-sm text-slate-300 bg-slate-800/50 px-3 py-1.5 rounded border border-slate-700">
                  <TrendingUp className="w-4 h-4 text-emerald-500" />
                  <span>Revenue Spiked +15% from Email Campaign</span>
                  <button className="text-brand-400 text-xs hover:underline ml-auto">View</button>
               </div>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard kpi={stats[0]} icon={DollarSign} />
        <StatsCard kpi={stats[1]} icon={Users} />
        <StatsCard kpi={stats[2]} icon={ShoppingBag} />
        <StatsCard kpi={stats[3]} icon={MousePointer} />
      </div>

      {/* Main Charts Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-white">Revenue Analytics</h2>
            <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-brand-500"></span>
                <span className="text-xs text-slate-400">Revenue</span>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff' }}
                    itemStyle={{ color: '#fff' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#14b8a6" strokeWidth={2} fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Live Activity */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg flex flex-col">
          <h2 className="text-lg font-semibold text-white mb-4">Live Activity</h2>
          <div className="flex-1 overflow-y-auto pr-2 space-y-4">
             {[1, 2, 3, 4, 5].map((_, i) => (
                 <div key={i} className="flex gap-3 items-start p-3 hover:bg-slate-800/50 rounded-lg transition-colors cursor-pointer group">
                    <div className="mt-1 w-2 h-2 rounded-full bg-brand-500 animate-pulse" />
                    <div className="flex-1">
                        <p className="text-sm text-white font-medium group-hover:text-brand-300 transition-colors">
                            New Order #492{i}
                        </p>
                        <p className="text-xs text-slate-400 mt-0.5">Just now • via Shopify</p>
                    </div>
                    <span className="text-xs font-bold text-emerald-400">+$129.00</span>
                 </div>
             ))}
          </div>
        </div>
      </div>

      {/* Marketing Performance Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                      <Megaphone className="w-5 h-5 text-purple-500" /> Social Ads Performance
                  </h2>
                  <div className="flex items-center gap-4 text-xs">
                      <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-purple-500"></div> Spend</div>
                      <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-emerald-400"></div> ROAS</div>
                  </div>
              </div>
              <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={adsData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                          <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                          <YAxis yAxisId="left" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `$${v}`} />
                          <YAxis yAxisId="right" orientation="right" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                          <Tooltip cursor={{fill: '#1e293b'}} contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }} />
                          <Bar yAxisId="left" dataKey="spend" fill="#a855f7" radius={[4, 4, 0, 0]} />
                          <Bar yAxisId="right" dataKey="roas" fill="#34d399" radius={[4, 4, 0, 0]} />
                      </BarChart>
                  </ResponsiveContainer>
              </div>
          </div>
          
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h3 className="text-white font-bold mb-4">Ad Insights</h3>
              <div className="space-y-4">
                  <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                      <p className="text-xs text-slate-400 uppercase font-bold mb-1">Blended ROAS</p>
                      <p className="text-2xl font-bold text-white">3.85x</p>
                      <p className="text-xs text-emerald-400 mt-1">+12% vs target</p>
                  </div>
                  <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                      <p className="text-xs text-slate-400 uppercase font-bold mb-1">Total Ad Spend</p>
                      <p className="text-2xl font-bold text-white">$12,450</p>
                  </div>
                  <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                      <p className="text-xs text-slate-400 uppercase font-bold mb-1">CPM (Avg)</p>
                      <p className="text-2xl font-bold text-white">$14.20</p>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};


import React, { useState } from 'react';
import { Search, Filter, CheckCircle, Plus, RefreshCcw, AlertCircle, ExternalLink, Webhook, X } from 'lucide-react';
import { Integration } from '../types';

const MOCK_INTEGRATIONS: Integration[] = [
  { id: '1', name: 'Shopify', category: 'ecommerce', status: 'connected', icon: 'https://cdn.svgporn.com/logos/shopify.svg', lastSync: '2 mins ago' },
  { id: '2', name: 'WooCommerce', category: 'ecommerce', status: 'disconnected', icon: 'https://cdn.svgporn.com/logos/woocommerce.svg' },
  { id: '4', name: 'Instagram', category: 'social', status: 'connected', icon: 'https://cdn.svgporn.com/logos/instagram-icon.svg', lastSync: '1h ago' },
  { id: '5', name: 'Meta Ads', category: 'social', status: 'connected', icon: 'https://cdn.svgporn.com/logos/meta-icon.svg', lastSync: '15m ago' },
  { id: '9', name: 'Stripe', category: 'payment', status: 'connected', icon: 'https://cdn.svgporn.com/logos/stripe.svg', lastSync: 'Live' },
  { id: '11', name: 'Google Sheets', category: 'marketing', status: 'disconnected', icon: 'https://cdn.svgporn.com/logos/google-sheets.svg' },
  { id: '12', name: 'Zapier', category: 'marketing', status: 'disconnected', icon: 'https://cdn.svgporn.com/logos/zapier.svg' },
  { id: '13', name: 'Slack', category: 'marketing', status: 'connected', icon: 'https://cdn.svgporn.com/logos/slack-icon.svg', lastSync: 'Live' },
  { id: '14', name: 'Klaviyo', category: 'marketing', status: 'disconnected', icon: 'https://cdn.svgporn.com/logos/klaviyo.svg' },
  { id: '15', name: 'TikTok', category: 'social', status: 'disconnected', icon: 'https://cdn.svgporn.com/logos/tiktok-icon.svg' },
];

export const Integrations: React.FC = () => {
  const [showWebhook, setShowWebhook] = useState(false);
  const [integrations, setIntegrations] = useState(MOCK_INTEGRATIONS);
  const [filter, setFilter] = useState('all');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Integrations Hub</h1>
        <button onClick={() => setShowWebhook(true)} className="bg-white text-slate-900 px-4 py-2 rounded-lg flex items-center gap-2 font-bold text-sm">
           <Webhook className="w-4 h-4" /> Custom Webhook
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {integrations.map(item => (
              <div key={item.id} className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col hover:border-slate-600 transition-colors">
                  <div className="flex justify-between items-start mb-4">
                      <img src={item.icon} className="w-10 h-10 object-contain" alt="" />
                      <span className={`px-2 py-1 rounded text-[10px] uppercase border ${item.status === 'connected' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-slate-800 text-slate-500 border-slate-700'}`}>{item.status}</span>
                  </div>
                  <h3 className="font-bold text-white">{item.name}</h3>
                  <p className="text-xs text-slate-500 mb-4 capitalize">{item.category}</p>
                  <button className={`mt-auto w-full py-2 rounded text-xs font-bold ${item.status === 'connected' ? 'bg-slate-800 text-white' : 'bg-brand-600 text-white'}`}>
                      {item.status === 'connected' ? 'Configure' : 'Connect'}
                  </button>
              </div>
          ))}
      </div>

      {showWebhook && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
              <div className="bg-slate-900 w-full max-w-md rounded-xl border border-slate-700 p-6 relative">
                  <button onClick={() => setShowWebhook(false)} className="absolute top-4 right-4 text-slate-500 hover:text-white"><X className="w-5 h-5" /></button>
                  <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Webhook className="w-5 h-5 text-brand-500" /> Custom Webhook</h3>
                  <div className="space-y-4">
                      <div>
                          <label className="text-xs text-slate-400">Endpoint URL</label>
                          <input className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white" placeholder="https://api.yoursite.com/webhook" />
                      </div>
                      <div>
                          <label className="text-xs text-slate-400">Secret Key</label>
                          <input className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white" type="password" value="whsec_..." readOnly />
                      </div>
                      <button className="w-full bg-brand-600 text-white py-2 rounded font-bold">Save Configuration</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

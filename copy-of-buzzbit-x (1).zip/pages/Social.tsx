
import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, Instagram, Twitter, Linkedin, Video, Plus, 
  MoreHorizontal, BarChart2, Grid, Sparkles, Image as ImageIcon, 
  Send, Clock, X, CheckCircle, Loader2, Youtube, UploadCloud, Folder
} from 'lucide-react';
import { SocialPost, SocialPlatform } from '../types';
import { generateSocialContent } from '../services/geminiService';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// --- MOCK DATA & CONSTANTS (Simplified for brevity) ---
const ANALYTICS_DATA = [{name:'Mon',reach:1200},{name:'Tue',reach:1800},{name:'Wed',reach:1400},{name:'Thu',reach:2200},{name:'Fri',reach:2800},{name:'Sat',reach:3500},{name:'Sun',reach:3100}];
const MOCK_MEDIA = [
    { id: 'm1', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30', name: 'Product Shot 1.jpg' },
    { id: 'm2', url: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e', name: 'Headphones Lifestyle.jpg' },
    { id: 'm3', url: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa', name: 'Bag Detail.jpg' },
];

export const Social: React.FC = () => {
  const [view, setView] = useState<'calendar' | 'analytics' | 'media'>('calendar');
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  // Basic Calendar & Analytics Logic retained...
  
  return (
    <div className="h-[calc(100vh-100px)] flex flex-col space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Social Automator</h1>
        <div className="flex items-center gap-3">
            <div className="bg-slate-900 p-1 rounded-lg border border-slate-800 flex">
                <button onClick={() => setView('calendar')} className={`px-4 py-2 rounded text-sm ${view === 'calendar' ? 'bg-brand-600 text-white' : 'text-slate-400'}`}>Calendar</button>
                <button onClick={() => setView('analytics')} className={`px-4 py-2 rounded text-sm ${view === 'analytics' ? 'bg-brand-600 text-white' : 'text-slate-400'}`}>Analytics</button>
                <button onClick={() => setView('media')} className={`px-4 py-2 rounded text-sm ${view === 'media' ? 'bg-brand-600 text-white' : 'text-slate-400'}`}>Media Library</button>
            </div>
            <button onClick={() => setShowCreateModal(true)} className="bg-white text-slate-900 px-4 py-2 rounded font-bold text-sm flex items-center gap-2">
                <Plus className="w-4 h-4" /> Create
            </button>
        </div>
      </div>

      {view === 'calendar' && (
          <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-6 flex items-center justify-center text-slate-500">
              Calendar View (Implementation retained from previous version)
          </div>
      )}

      {view === 'analytics' && (
          <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h3 className="text-white font-bold mb-4">Reach Analytics</h3>
              <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={ANALYTICS_DATA}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                          <XAxis dataKey="name" stroke="#64748b" />
                          <YAxis stroke="#64748b" />
                          <Tooltip />
                          <Area type="monotone" dataKey="reach" stroke="#14b8a6" fill="#14b8a6" fillOpacity={0.2} />
                      </AreaChart>
                  </ResponsiveContainer>
              </div>
          </div>
      )}

      {view === 'media' && (
          <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex justify-between mb-6">
                  <h2 className="text-lg font-bold text-white">Media Assets</h2>
                  <button className="border border-slate-700 text-slate-300 px-4 py-2 rounded flex items-center gap-2 hover:bg-slate-800">
                      <UploadCloud className="w-4 h-4" /> Upload Folder
                  </button>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  <div className="aspect-square border-2 border-dashed border-slate-700 rounded-xl flex flex-col items-center justify-center text-slate-500 hover:border-brand-500 hover:text-brand-400 cursor-pointer transition-colors">
                      <Plus className="w-8 h-8 mb-2" />
                      <span className="text-xs">Upload</span>
                  </div>
                  {MOCK_MEDIA.map(m => (
                      <div key={m.id} className="group relative aspect-square rounded-xl overflow-hidden border border-slate-800">
                          <img src={m.url} className="w-full h-full object-cover" alt={m.name} />
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-medium">
                              {m.name}
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      )}
    </div>
  );
};

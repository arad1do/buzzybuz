
import React, { useState } from 'react';
import { Package, ShoppingCart, DollarSign, Plus, Search, MoreVertical, TrendingUp, Filter, ChevronDown, ChevronUp, CreditCard, Truck, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Product, Order, Transaction } from '../types';

export const Commerce: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'finance'>('products');
  const [expandedProductId, setExpandedProductId] = useState<string | null>(null);
  
  // Mock Data
  const [products, setProducts] = useState<Product[]>([
    { 
        id: '1', name: 'Premium Leather Bag', sku: 'BAG-BASE', price: 129.99, stock: 45, category: 'Accessories', status: 'active',
        variants: [
            { id: 'v1', name: 'Brown / Leather', sku: 'BAG-BRN', price: 129.99, stock: 20 },
            { id: 'v2', name: 'Black / Leather', sku: 'BAG-BLK', price: 129.99, stock: 25 }
        ] 
    },
    { 
        id: '2', name: 'Tech Runner Sneakers', sku: 'SHOE-RN', price: 89.00, stock: 150, category: 'Footwear', status: 'active',
        variants: [
            { id: 'v3', name: 'White / 9', sku: 'SHOE-RN-W9', price: 89.00, stock: 50 },
            { id: 'v4', name: 'White / 10', sku: 'SHOE-RN-W10', price: 89.00, stock: 45 },
            { id: 'v5', name: 'Black / 9', sku: 'SHOE-RN-B9', price: 89.00, stock: 55 }
        ] 
    },
  ]);

  const [orders, setOrders] = useState<Order[]>([
    { id: 'ORD-7742', customer: 'Sarah Connor', email: 'sarah@sky.net', total: 249.50, status: 'pending', paymentStatus: 'paid', date: '2023-10-24', items: 1 },
    { id: 'ORD-7741', customer: 'Kyle Reese', email: 'kyle@res.ist', total: 58.00, status: 'shipped', paymentStatus: 'paid', date: '2023-10-23', items: 2 },
    { id: 'ORD-7740', customer: 'T-800', email: 'model101@cyberdyne.sys', total: 1200.00, status: 'returned', paymentStatus: 'refunded', date: '2023-10-20', items: 1 },
  ]);

  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: 'TRX-9921', type: 'income', amount: 249.50, category: 'Sales', description: 'Order #ORD-7742 Payment', date: '2023-10-24', status: 'cleared' },
    { id: 'TRX-9920', type: 'expense', amount: 14.00, category: 'Shipping', description: 'Shipping Label UPS', date: '2023-10-23', status: 'cleared' },
    { id: 'TRX-9919', type: 'expense', amount: 250.00, category: 'Marketing', description: 'Facebook Ads Daily Spend', date: '2023-10-23', status: 'pending' },
  ]);

  const toggleProductExpand = (id: string) => {
    setExpandedProductId(expandedProductId === id ? null : id);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Commerce Hub</h1>
          <p className="text-slate-400">Central command for inventory, fulfillment, and finance.</p>
        </div>
        <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
          <button 
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'products' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
          >
            Products
          </button>
          <button 
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'orders' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
          >
            Orders
          </button>
          <button 
            onClick={() => setActiveTab('finance')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${activeTab === 'finance' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
          >
            Finance
          </button>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg min-h-[600px] flex flex-col">
        {/* Common Toolbar */}
        <div className="p-4 border-b border-slate-800 flex flex-col md:flex-row justify-between items-center bg-slate-900 gap-4">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder={`Search ${activeTab}...`}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:border-brand-500 outline-none"
            />
          </div>
          <div className="flex gap-3 w-full md:w-auto">
            <button className="p-2 text-slate-400 hover:text-white border border-slate-700 rounded-lg hover:bg-slate-800">
              <Filter className="w-4 h-4" />
            </button>
            <button className="flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex-1 md:flex-none">
              <Plus className="w-4 h-4" />
              Add {activeTab === 'finance' ? 'Entry' : activeTab.slice(0, -1)}
            </button>
          </div>
        </div>

        {/* --- PRODUCTS TAB --- */}
        {activeTab === 'products' && (
          <div className="flex-1 overflow-auto">
            <table className="w-full text-left text-sm text-slate-400">
              <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-4 w-10"></th>
                  <th className="px-6 py-4">Product</th>
                  <th className="px-6 py-4">SKU</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4">Stock</th>
                  <th className="px-6 py-4 text-right">Price</th>
                  <th className="px-6 py-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {products.map((product) => (
                  <React.Fragment key={product.id}>
                      <tr className="hover:bg-slate-800/30 group cursor-pointer" onClick={() => toggleProductExpand(product.id)}>
                        <td className="px-6 py-4">
                            {expandedProductId === product.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </td>
                        <td className="px-6 py-4 font-medium text-white flex items-center gap-3">
                          <div className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center text-slate-500">
                            <Package className="w-4 h-4" />
                          </div>
                          <div>
                              <div>{product.name}</div>
                              <div className="text-xs text-slate-500">{product.variants.length} Variants</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 font-mono text-xs">{product.sku}</td>
                        <td className="px-6 py-4"><span className="px-2 py-1 bg-slate-800 rounded-full text-xs border border-slate-700">{product.category}</span></td>
                        <td className="px-6 py-4">
                          <span className={product.stock < 20 ? 'text-red-400 font-medium' : 'text-emerald-400'}>
                            {product.stock} units
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right text-white font-medium">${product.price.toFixed(2)}</td>
                        <td className="px-6 py-4 text-right">
                            <span className="px-2 py-1 rounded text-xs font-bold bg-emerald-500/10 text-emerald-400 uppercase">
                                {product.status}
                            </span>
                        </td>
                      </tr>
                      {expandedProductId === product.id && (
                          <tr className="bg-slate-950/50">
                              <td colSpan={7} className="p-4 pl-20">
                                  <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
                                      <table className="w-full text-xs">
                                          <thead className="bg-slate-950 text-slate-500">
                                              <tr>
                                                  <th className="px-4 py-2 text-left">Variant Name</th>
                                                  <th className="px-4 py-2 text-left">SKU</th>
                                                  <th className="px-4 py-2 text-right">Stock</th>
                                                  <th className="px-4 py-2 text-right">Price</th>
                                                  <th className="px-4 py-2 text-right">Action</th>
                                              </tr>
                                          </thead>
                                          <tbody className="divide-y divide-slate-800">
                                              {product.variants.map(variant => (
                                                  <tr key={variant.id} className="hover:bg-slate-800/50">
                                                      <td className="px-4 py-2 font-medium text-slate-300">{variant.name}</td>
                                                      <td className="px-4 py-2 font-mono text-slate-500">{variant.sku}</td>
                                                      <td className="px-4 py-2 text-right text-slate-300">{variant.stock}</td>
                                                      <td className="px-4 py-2 text-right text-slate-300">${variant.price}</td>
                                                      <td className="px-4 py-2 text-right">
                                                          <button className="text-brand-400 hover:underline">Edit</button>
                                                      </td>
                                                  </tr>
                                              ))}
                                          </tbody>
                                      </table>
                                      <div className="p-2 border-t border-slate-800 text-center">
                                          <button className="text-xs text-slate-500 hover:text-white flex items-center justify-center gap-1 w-full">
                                              <Plus className="w-3 h-3" /> Add Variant
                                          </button>
                                      </div>
                                  </div>
                              </td>
                          </tr>
                      )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* --- ORDERS TAB --- */}
        {activeTab === 'orders' && (
          <div className="flex-1 overflow-auto">
            <table className="w-full text-left text-sm text-slate-400">
              <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-4">Order ID</th>
                  <th className="px-6 py-4">Customer</th>
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4">Fulfillment</th>
                  <th className="px-6 py-4">Payment</th>
                  <th className="px-6 py-4 text-right">Total</th>
                  <th className="px-6 py-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {orders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-800/30 group">
                    <td className="px-6 py-4 font-medium text-brand-400 font-mono">{order.id}</td>
                    <td className="px-6 py-4">
                        <div className="text-white font-medium">{order.customer}</div>
                        <div className="text-xs text-slate-500">{order.email}</div>
                    </td>
                    <td className="px-6 py-4">{order.date}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs border capitalize inline-flex items-center gap-1 ${
                        order.status === 'delivered' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' :
                        order.status === 'shipped' ? 'bg-blue-500/10 border-blue-500/20 text-blue-400' :
                        order.status === 'returned' ? 'bg-red-500/10 border-red-500/20 text-red-400' :
                        'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
                      }`}>
                        {order.status === 'shipped' && <Truck className="w-3 h-3" />}
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                       <span className={`px-2 py-1 rounded-full text-xs border capitalize inline-flex items-center gap-1 ${
                        order.paymentStatus === 'paid' ? 'bg-slate-800 text-slate-300 border-slate-700' : 
                        'bg-red-900/20 text-red-400 border-red-500/30'
                       }`}>
                         {order.paymentStatus === 'paid' && <CreditCard className="w-3 h-3" />}
                         {order.paymentStatus}
                       </span>
                    </td>
                    <td className="px-6 py-4 text-right text-white font-bold">${order.total.toFixed(2)}</td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-slate-500 hover:text-white"><MoreVertical className="w-4 h-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* --- FINANCE TAB --- */}
        {activeTab === 'finance' && (
          <div className="flex-1 overflow-auto bg-slate-950/30">
             {/* Finance KPIs */}
             <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6 border-b border-slate-800">
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-sm">
                   <p className="text-slate-500 text-xs font-bold uppercase mb-1">Net Income (MTD)</p>
                   <div className="flex items-end justify-between">
                      <h3 className="text-2xl font-bold text-white">$10,336.50</h3>
                      <span className="text-emerald-400 text-xs flex items-center bg-emerald-500/10 px-1.5 py-0.5 rounded">+12.5%</span>
                   </div>
                </div>
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-sm">
                   <p className="text-slate-500 text-xs font-bold uppercase mb-1">Total Expenses</p>
                   <div className="flex items-end justify-between">
                      <h3 className="text-2xl font-bold text-white">$2,114.00</h3>
                      <span className="text-red-400 text-xs flex items-center bg-red-500/10 px-1.5 py-0.5 rounded">+4.2%</span>
                   </div>
                </div>
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 shadow-sm">
                   <p className="text-slate-500 text-xs font-bold uppercase mb-1">Burn Rate</p>
                   <div className="flex items-end justify-between">
                      <h3 className="text-2xl font-bold text-white">$450/day</h3>
                      <span className="text-slate-400 text-xs flex items-center">Stable</span>
                   </div>
                </div>
             </div>

             <div className="p-6">
               <h3 className="text-lg font-bold text-white mb-4">General Ledger</h3>
               <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                 <table className="w-full text-left text-sm text-slate-400">
                    <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium">
                        <tr>
                            <th className="px-4 py-3">Transaction ID</th>
                            <th className="px-4 py-3">Date</th>
                            <th className="px-4 py-3">Category</th>
                            <th className="px-4 py-3">Description</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3 text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                        {transactions.map(trx => (
                            <tr key={trx.id} className="hover:bg-slate-800/30 transition-colors">
                                <td className="px-4 py-3 font-mono text-xs text-slate-500">{trx.id}</td>
                                <td className="px-4 py-3">{trx.date}</td>
                                <td className="px-4 py-3">
                                    <span className="px-2 py-1 bg-slate-800 rounded text-xs border border-slate-700">{trx.category}</span>
                                </td>
                                <td className="px-4 py-3 text-white">{trx.description}</td>
                                <td className="px-4 py-3">
                                    <span className={`text-xs flex items-center gap-1 ${trx.status === 'cleared' ? 'text-emerald-400' : 'text-yellow-400'}`}>
                                        {trx.status === 'cleared' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                                        {trx.status}
                                    </span>
                                </td>
                                <td className={`px-4 py-3 text-right font-bold ${trx.type === 'income' ? 'text-emerald-400' : 'text-white'}`}>
                                    {trx.type === 'income' ? '+' : '-'}${trx.amount.toFixed(2)}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                 </table>
               </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

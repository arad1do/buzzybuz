
import React, { useState } from 'react';
import { 
  Users, Target, Briefcase, Package, ShoppingCart, DollarSign, 
  Search, Filter, Plus, Download, MoreHorizontal, ChevronDown, 
  ChevronUp, Zap, Truck, CreditCard, ArrowUpRight, ArrowDownRight,
  Star, AlertTriangle, LayoutGrid
} from 'lucide-react';
import { Customer, Segment, Product, Order, Transaction, LeadStage } from '../types';

// --- MOCK DATA ---
// Merged from Customers and Commerce
const MOCK_CUSTOMERS: Customer[] = [
  { id: '1', name: 'Alice Freeman', email: 'alice.f@example.com', phone: '+1 555-0101', type: 'customer', status: 'active', ltv: 1240.50, segment: 'VIP', lastActive: '2 mins ago', riskScore: 5, tags: ['High Value', 'Frequent Buyer'], nextBestAction: 'Send VIP Early Access' },
  { id: '2', name: 'Bob Smith', email: 'bob.smith@example.com', type: 'customer', status: 'active', ltv: 450.00, segment: 'Loyal', lastActive: '4 hours ago', riskScore: 15, tags: ['Apparel'], nextBestAction: 'Recommend matching items' },
  { id: '3', name: 'TechCorp Inc.', email: 'procurement@techcorp.com', type: 'lead', status: 'lead', leadStage: 'proposal', ltv: 0, segment: 'B2B Lead', lastActive: '1 day ago', riskScore: 0, company: 'TechCorp', tags: ['B2B', 'Bulk'], nextBestAction: 'Follow up on quote' },
];

const MOCK_PRODUCTS: Product[] = [
  { 
      id: '1', name: 'Premium Leather Bag', sku: 'BAG-BASE', price: 129.99, stock: 45, category: 'Accessories', status: 'active',
      variants: [
          { id: 'v1', name: 'Brown / Leather', sku: 'BAG-BRN', price: 129.99, stock: 20 },
          { id: 'v2', name: 'Black / Leather', sku: 'BAG-BLK', price: 129.99, stock: 25 }
      ] 
  },
  { 
      id: '2', name: 'Tech Runner Sneakers', sku: 'SHOE-RN', price: 89.00, stock: 150, category: 'Footwear', status: 'active',
      variants: [
          { id: 'v3', name: 'White / 9', sku: 'SHOE-RN-W9', price: 89.00, stock: 50 },
          { id: 'v4', name: 'White / 10', sku: 'SHOE-RN-W10', price: 89.00, stock: 45 }
      ] 
  },
];

const MOCK_ORDERS: Order[] = [
  { id: 'ORD-7742', customer: 'Sarah Connor', email: 'sarah@sky.net', total: 249.50, status: 'pending', paymentStatus: 'paid', date: '2023-10-24', items: 1 },
  { id: 'ORD-7741', customer: 'Kyle Reese', email: 'kyle@res.ist', total: 58.00, status: 'shipped', paymentStatus: 'paid', date: '2023-10-23', items: 2 },
];

const MOCK_TRANSACTIONS: Transaction[] = [
  { id: 'TRX-9921', type: 'income', amount: 249.50, category: 'Sales', description: 'Order #ORD-7742 Payment', date: '2023-10-24', status: 'cleared' },
  { id: 'TRX-9920', type: 'expense', amount: 14.00, category: 'Shipping', description: 'Shipping Label UPS', date: '2023-10-23', status: 'cleared' },
];

export const BusinessHub: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'customers' | 'leads' | 'products' | 'orders' | 'finance'>('customers');
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedProductId, setExpandedProductId] = useState<string | null>(null);

  const customers = MOCK_CUSTOMERS.filter(c => c.type === 'customer');
  const leads = MOCK_CUSTOMERS.filter(c => c.type === 'lead');

  const renderToolbar = (title: string, action: string) => (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div className="relative flex-1 w-full md:max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
                type="text" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={`Search ${title}...`} 
                className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-slate-200 focus:border-brand-500 outline-none"
            />
        </div>
        <div className="flex gap-3 w-full md:w-auto">
            <button className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-300 hover:text-white transition-colors flex items-center gap-2">
                <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="px-4 py-2 bg-brand-600 hover:bg-brand-500 text-white rounded-lg font-medium transition-colors flex items-center gap-2 shadow-lg shadow-brand-500/20">
                <Plus className="w-4 h-4" /> {action}
            </button>
        </div>
    </div>
  );

  return (
    <div className="space-y-6 h-[calc(100vh-100px)] flex flex-col">
      {/* Header & Nav */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <LayoutGrid className="w-7 h-7 text-brand-500" />
            Business Hub
          </h1>
          <p className="text-slate-400">Unified command center for CRM, Inventory, and Finance.</p>
        </div>
        
        <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800 overflow-x-auto w-full lg:w-auto">
          {[
              { id: 'customers', icon: Users, label: 'Customers' },
              { id: 'leads', icon: Target, label: 'Leads' },
              { id: 'products', icon: Package, label: 'Products' },
              { id: 'orders', icon: ShoppingCart, label: 'Orders' },
              { id: 'finance', icon: DollarSign, label: 'Finance' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-all whitespace-nowrap ${
                activeTab === tab.id ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl flex flex-col">
        
        {/* --- CUSTOMERS --- */}
        {activeTab === 'customers' && (
            <div className="flex-1 flex flex-col">
                <div className="p-4 border-b border-slate-800 bg-slate-950/50">
                    {renderToolbar('contacts', 'Add Customer')}
                </div>
                <div className="flex-1 overflow-auto">
                    <table className="w-full text-left text-sm text-slate-400">
                        <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium sticky top-0 z-10">
                            <tr>
                                <th className="px-6 py-4">Customer</th>
                                <th className="px-6 py-4">Segment</th>
                                <th className="px-6 py-4 text-right">LTV</th>
                                <th className="px-6 py-4">Risk</th>
                                <th className="px-6 py-4">Next Action</th>
                                <th className="px-6 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800">
                            {customers.map(c => (
                                <tr key={c.id} className="hover:bg-slate-800/30 transition-colors group cursor-pointer">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-700 to-slate-600 flex items-center justify-center text-white font-bold text-xs">
                                                {c.name.charAt(0)}
                                            </div>
                                            <div>
                                                <p className="font-medium text-white">{c.name}</p>
                                                <p className="text-xs text-slate-500">{c.email}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4"><span className="px-2 py-1 bg-slate-800 rounded-full text-xs border border-slate-700">{c.segment}</span></td>
                                    <td className="px-6 py-4 text-right text-white font-medium">${c.ltv.toLocaleString()}</td>
                                    <td className="px-6 py-4">
                                        <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                            <div className={`h-full ${c.riskScore > 10 ? 'bg-red-500' : 'bg-emerald-500'}`} style={{ width: `${c.riskScore}%` }}></div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-xs text-brand-400 flex items-center gap-1">
                                        <Zap className="w-3 h-3" /> {c.nextBestAction}
                                    </td>
                                    <td className="px-6 py-4 text-right"><MoreHorizontal className="w-4 h-4 text-slate-500" /></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {/* --- LEADS --- */}
        {activeTab === 'leads' && (
            <div className="flex-1 p-4 overflow-x-auto bg-slate-950/30">
                <div className="flex gap-4 min-w-max h-full">
                    {['new', 'contacted', 'qualified', 'proposal', 'won'].map((stage) => (
                        <div key={stage} className="w-72 flex flex-col bg-slate-900 border border-slate-800 rounded-xl h-full">
                            <div className="p-3 border-b border-slate-800 flex justify-between items-center bg-slate-950/50 rounded-t-xl">
                                <h3 className="font-bold text-white capitalize flex items-center gap-2">
                                    <div className={`w-2 h-2 rounded-full ${stage === 'won' ? 'bg-emerald-500' : 'bg-brand-500'}`}></div>
                                    {stage}
                                </h3>
                                <span className="bg-slate-800 text-slate-400 px-2 py-0.5 rounded text-xs">
                                    {leads.filter(l => l.leadStage === stage).length}
                                </span>
                            </div>
                            <div className="flex-1 p-3 space-y-3 overflow-y-auto custom-scrollbar">
                                {leads.filter(l => l.leadStage === stage).map(lead => (
                                    <div key={lead.id} className="bg-slate-800 border border-slate-700 p-3 rounded-lg hover:border-brand-500 cursor-grab active:cursor-grabbing shadow-sm transition-all group">
                                        <div className="flex justify-between items-start mb-2">
                                            <span className="text-xs text-slate-400 font-mono">{lead.company || 'Individual'}</span>
                                            <MoreHorizontal className="w-3 h-3 text-slate-600" />
                                        </div>
                                        <h4 className="font-bold text-white text-sm mb-1">{lead.name}</h4>
                                        <p className="text-xs text-slate-500 mb-3">{lead.email}</p>
                                        <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between">
                                            <div className="flex items-center gap-1 text-[10px] text-brand-400">
                                                <Zap className="w-3 h-3" /> {lead.nextBestAction}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                                <button className="w-full py-2 border border-dashed border-slate-700 rounded-lg text-slate-500 text-sm hover:bg-slate-800 hover:text-white transition-colors">
                                    + Add Lead
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        )}

        {/* --- PRODUCTS --- */}
        {activeTab === 'products' && (
             <div className="flex-1 flex flex-col">
                <div className="p-4 border-b border-slate-800 bg-slate-950/50">
                    {renderToolbar('inventory', 'Add Product')}
                </div>
                <div className="flex-1 overflow-auto">
                    <table className="w-full text-left text-sm text-slate-400">
                        <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium sticky top-0 z-10">
                            <tr>
                                <th className="px-6 py-4 w-10"></th>
                                <th className="px-6 py-4">Product</th>
                                <th className="px-6 py-4">SKU</th>
                                <th className="px-6 py-4">Stock</th>
                                <th className="px-6 py-4 text-right">Price</th>
                                <th className="px-6 py-4 text-right">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800">
                            {MOCK_PRODUCTS.map((product) => (
                                <React.Fragment key={product.id}>
                                    <tr className="hover:bg-slate-800/30 group cursor-pointer" onClick={() => setExpandedProductId(expandedProductId === product.id ? null : product.id)}>
                                        <td className="px-6 py-4">
                                            {expandedProductId === product.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                                        </td>
                                        <td className="px-6 py-4 font-medium text-white flex items-center gap-3">
                                            <div className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center text-slate-500"><Package className="w-4 h-4" /></div>
                                            <div>
                                                <div>{product.name}</div>
                                                <div className="text-xs text-slate-500">{product.variants.length} Variants</div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 font-mono text-xs">{product.sku}</td>
                                        <td className="px-6 py-4"><span className={product.stock < 20 ? 'text-red-400' : 'text-emerald-400'}>{product.stock} units</span></td>
                                        <td className="px-6 py-4 text-right text-white font-medium">${product.price.toFixed(2)}</td>
                                        <td className="px-6 py-4 text-right"><span className="px-2 py-1 rounded text-xs font-bold bg-emerald-500/10 text-emerald-400 uppercase">{product.status}</span></td>
                                    </tr>
                                    {expandedProductId === product.id && (
                                        <tr className="bg-slate-950/50">
                                            <td colSpan={6} className="p-4 pl-20">
                                                <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
                                                    <table className="w-full text-xs">
                                                        <thead className="bg-slate-950 text-slate-500">
                                                            <tr>
                                                                <th className="px-4 py-2 text-left">Variant</th>
                                                                <th className="px-4 py-2 text-left">SKU</th>
                                                                <th className="px-4 py-2 text-right">Stock</th>
                                                                <th className="px-4 py-2 text-right">Price</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {product.variants.map(v => (
                                                                <tr key={v.id} className="border-t border-slate-800">
                                                                    <td className="px-4 py-2 text-slate-300">{v.name}</td>
                                                                    <td className="px-4 py-2 font-mono">{v.sku}</td>
                                                                    <td className="px-4 py-2 text-right">{v.stock}</td>
                                                                    <td className="px-4 py-2 text-right">${v.price}</td>
                                                                </tr>
                                                            ))}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                </React.Fragment>
                            ))}
                        </tbody>
                    </table>
                </div>
             </div>
        )}

        {/* --- ORDERS --- */}
        {activeTab === 'orders' && (
            <div className="flex-1 flex flex-col">
                <div className="p-4 border-b border-slate-800 bg-slate-950/50">
                    {renderToolbar('orders', 'Create Order')}
                </div>
                <div className="flex-1 overflow-auto">
                    <table className="w-full text-left text-sm text-slate-400">
                        <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium sticky top-0 z-10">
                            <tr>
                                <th className="px-6 py-4">Order ID</th>
                                <th className="px-6 py-4">Customer</th>
                                <th className="px-6 py-4">Status</th>
                                <th className="px-6 py-4">Payment</th>
                                <th className="px-6 py-4 text-right">Total</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800">
                            {MOCK_ORDERS.map(order => (
                                <tr key={order.id} className="hover:bg-slate-800/30 transition-colors">
                                    <td className="px-6 py-4 font-mono text-brand-400">{order.id}</td>
                                    <td className="px-6 py-4">
                                        <div className="text-white font-medium">{order.customer}</div>
                                        <div className="text-xs text-slate-500">{order.email}</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-2 py-1 rounded-full text-xs border border-slate-700 bg-slate-800 capitalize flex items-center gap-1 w-fit">
                                            {order.status === 'shipped' && <Truck className="w-3 h-3" />}
                                            {order.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className="px-2 py-1 rounded-full text-xs border border-slate-700 bg-slate-800 capitalize flex items-center gap-1 w-fit">
                                            <CreditCard className="w-3 h-3" /> {order.paymentStatus}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right text-white font-bold">${order.total.toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {/* --- FINANCE --- */}
        {activeTab === 'finance' && (
             <div className="flex-1 overflow-auto bg-slate-950/30">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6 border-b border-slate-800">
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                        <p className="text-slate-500 text-xs font-bold uppercase mb-1">Net Income</p>
                        <h3 className="text-2xl font-bold text-white">$10,336.50</h3>
                    </div>
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                        <p className="text-slate-500 text-xs font-bold uppercase mb-1">Expenses</p>
                        <h3 className="text-2xl font-bold text-white">$2,114.00</h3>
                    </div>
                    <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                        <p className="text-slate-500 text-xs font-bold uppercase mb-1">Profit Margin</p>
                        <h3 className="text-2xl font-bold text-white">22.4%</h3>
                    </div>
                </div>
                <div className="p-6">
                    <h3 className="text-lg font-bold text-white mb-4">Ledger</h3>
                    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                        <table className="w-full text-left text-sm text-slate-400">
                            <thead className="bg-slate-950 text-slate-200 uppercase text-xs font-medium">
                                <tr>
                                    <th className="px-4 py-3">ID</th>
                                    <th className="px-4 py-3">Date</th>
                                    <th className="px-4 py-3">Category</th>
                                    <th className="px-4 py-3">Description</th>
                                    <th className="px-4 py-3 text-right">Amount</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800">
                                {MOCK_TRANSACTIONS.map(trx => (
                                    <tr key={trx.id} className="hover:bg-slate-800/30">
                                        <td className="px-4 py-3 font-mono text-xs">{trx.id}</td>
                                        <td className="px-4 py-3">{trx.date}</td>
                                        <td className="px-4 py-3"><span className="px-2 py-1 bg-slate-800 rounded text-xs border border-slate-700">{trx.category}</span></td>
                                        <td className="px-4 py-3 text-white">{trx.description}</td>
                                        <td className={`px-4 py-3 text-right font-bold ${trx.type === 'income' ? 'text-emerald-400' : 'text-white'}`}>
                                            {trx.type === 'income' ? '+' : '-'}${trx.amount.toFixed(2)}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
             </div>
        )}
      </div>
    </div>
  );
};

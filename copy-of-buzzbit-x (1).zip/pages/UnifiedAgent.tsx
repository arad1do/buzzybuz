
import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, MessageSquare, Settings, Zap, Activity, MessageCircle, 
  CheckCircle, AlertTriangle, User, RefreshCcw, Plus,
  PieChart, Gauge, Terminal, Play, Edit3, ToggleLeft, ToggleRight,
  Smile, Briefcase, Coffee, Crown, Sparkles, Send, Loader2,
  Clock, Instagram, Twitter, Facebook, X, Mail, Phone, Paperclip, MoreVertical
} from 'lucide-react';
import { Intent, BrandToneConfig, FollowUpRule, ChatMessage, InboxThread } from '../types';
import { simulateUnifiedAgent, optimizeIntent } from '../services/geminiService';

// --- MOCK INBOX THREADS ---
const INBOX_THREADS: InboxThread[] = [
  { id: '1', customerName: 'Sarah Jenkins', lastMessage: 'I haven\'t received my tracking number yet.', platform: 'whatsapp', timestamp: '10:42 AM', unread: true, tags: ['Support', 'Order'] },
  { id: '2', customerName: 'Mike Ross', lastMessage: 'Can I return the shoes if they don\'t fit?', platform: 'chat', timestamp: 'Yesterday', unread: false, tags: ['Question'] },
  { id: '3', customerName: 'Emily Blunt', lastMessage: 'Thanks for the discount code!', platform: 'sms', timestamp: 'Yesterday', unread: false, tags: ['Feedback'] },
];

// --- EXTENDED MOCK INTENTS (Simulating 100) ---
const generateMockIntents = (): Intent[] => {
  const categories = ['sales', 'service', 'booking', 'info', 'engagement'] as const;
  const intents: Intent[] = [
    { id: '1', name: 'Product Inquiry', category: 'sales', description: 'Questions about product details', triggers: ['price', 'cost', 'details'], responseTemplate: 'Our {{product}} is a best-seller!', isEnabled: true, automationRate: 95 },
    { id: '2', name: 'Order Status', category: 'service', description: 'Where is my order?', triggers: ['tracking', 'where', 'status'], responseTemplate: 'Checking your order...', isEnabled: true, automationRate: 98 },
    { id: '3', name: 'Returns', category: 'service', description: 'Return policy', triggers: ['return', 'refund'], responseTemplate: 'Returns are free within 30 days.', isEnabled: true, automationRate: 85 },
    // Generating more to simulate scale
  ];

  for (let i = 4; i <= 50; i++) {
    intents.push({
      id: i.toString(),
      name: `Intent #${i} - ${['Pricing', 'Shipping', 'Warranty', 'Size Guide', 'Colors'][i % 5]}`,
      category: categories[i % 5],
      description: `Auto-generated intent description for variation ${i}`,
      triggers: ['trigger', 'keyword', 'question'],
      responseTemplate: 'This is an automated response template.',
      isEnabled: Math.random() > 0.2,
      automationRate: Math.floor(Math.random() * 20) + 80
    });
  }
  return intents;
};

const MOCK_FOLLOWUPS: FollowUpRule[] = [
  { id: 'f1', type: 'abandoned_cart', name: 'Cart Recovery (1hr)', delay: 60, isEnabled: true, template: 'Hi {{name}}, you left items in your cart...' },
  { id: 'f2', type: 'post_purchase', name: 'Thank You + Upsell', delay: 1440, isEnabled: true, template: 'Thanks for ordering! Check out these matching items...' },
  { id: 'f3', type: 'win_back', name: 'We Miss You (30d)', delay: 43200, isEnabled: false, template: 'It\'s been a while! Here is 10% off.' },
];

export const UnifiedAgent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'inbox' | 'dashboard' | 'intents' | 'personality' | 'simulator'>('dashboard');
  
  // Inbox State
  const [selectedThread, setSelectedThread] = useState<string | null>(INBOX_THREADS[0].id);
  const [replyText, setReplyText] = useState('');

  // Config State
  const [brandTone, setBrandTone] = useState<BrandToneConfig>({ preset: 'friendly', customInstructions: 'Be helpful.', emojiUsage: 'moderate' });
  const [intents, setIntents] = useState(generateMockIntents());
  
  // Simulator State
  const [simMessages, setSimMessages] = useState<ChatMessage[]>([{ id: 'init', role: 'model', text: 'Unified Agent Online.', timestamp: new Date() }]);
  const [simInput, setSimInput] = useState('');
  const [isSimulating, setIsSimulating] = useState(false);
  
  // Intent Editor
  const [editingIntent, setEditingIntent] = useState<Intent | null>(null);

  const handleSimulate = async () => {
    if (!simInput.trim() || isSimulating) return;
    setSimMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', text: simInput, timestamp: new Date() }]);
    setSimInput('');
    setIsSimulating(true);
    const res = await simulateUnifiedAgent(simInput, brandTone.preset, 'whatsapp');
    setSimMessages(prev => [...prev, { id: (Date.now()+1).toString(), role: 'model', text: res.text, timestamp: new Date() }]);
    setIsSimulating(false);
  };

  const handleAiRewrite = async () => {
    if (!editingIntent) return;
    const optimized = await optimizeIntent(editingIntent.triggers.join(', '), editingIntent.responseTemplate);
    setEditingIntent({ ...editingIntent, triggers: optimized.triggers, responseTemplate: optimized.response });
  };

  return (
    <div className="space-y-6 h-[calc(100vh-100px)] flex flex-col">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Bot className="w-7 h-7 text-brand-500" /> Unified Agent
          </h1>
          <p className="text-slate-400">WhatsApp, DMs, and Messenger Automation Center.</p>
        </div>
        <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
          {['dashboard', 'inbox', 'intents', 'personality', 'simulator'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-4 py-2 rounded-md text-sm font-medium capitalize transition-all ${
                activeTab === tab ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        
        {/* --- DASHBOARD --- */}
        {activeTab === 'dashboard' && (
            <div className="overflow-y-auto space-y-6 p-1">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
                        <p className="text-slate-400 text-xs uppercase font-bold">Total Conversations</p>
                        <p className="text-2xl font-bold text-white">12,540</p>
                        <span className="text-emerald-400 text-xs">+15% this week</span>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
                        <p className="text-slate-400 text-xs uppercase font-bold">Automation Rate</p>
                        <p className="text-2xl font-bold text-white">94.5%</p>
                        <span className="text-emerald-400 text-xs">+2.1% improvement</span>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
                        <p className="text-slate-400 text-xs uppercase font-bold">Avg Response Time</p>
                        <p className="text-2xl font-bold text-white">1.8s</p>
                        <span className="text-slate-400 text-xs">Instant</span>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
                        <p className="text-slate-400 text-xs uppercase font-bold">Escalations</p>
                        <p className="text-2xl font-bold text-white">5.5%</p>
                        <span className="text-slate-400 text-xs">Within limits</span>
                    </div>
                </div>
                
                {/* Platforms Breakdown */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                        <h3 className="text-white font-bold mb-4">Platform Volume</h3>
                        <div className="space-y-4">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2 text-sm text-slate-300"><MessageCircle className="w-4 h-4 text-green-500"/> WhatsApp</div>
                                <div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><div className="w-[65%] h-full bg-green-500"></div></div>
                                <span className="text-xs text-white">65%</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2 text-sm text-slate-300"><Instagram className="w-4 h-4 text-pink-500"/> Instagram</div>
                                <div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><div className="w-[25%] h-full bg-pink-500"></div></div>
                                <span className="text-xs text-white">25%</span>
                            </div>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2 text-sm text-slate-300"><MessageCircle className="w-4 h-4 text-blue-500"/> Messenger</div>
                                <div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden"><div className="w-[10%] h-full bg-blue-500"></div></div>
                                <span className="text-xs text-white">10%</span>
                            </div>
                        </div>
                    </div>
                    <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6">
                        <h3 className="text-white font-bold mb-4">Recent Activity</h3>
                        <div className="space-y-3">
                            {[1,2,3].map(i => (
                                <div key={i} className="flex items-center justify-between p-3 bg-slate-950/50 rounded-lg border border-slate-800/50">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center"><User className="w-4 h-4 text-slate-400"/></div>
                                        <div>
                                            <p className="text-sm text-white font-medium">Order Status Inquiry</p>
                                            <p className="text-xs text-slate-500">User +1 555... • WhatsApp</p>
                                        </div>
                                    </div>
                                    <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">Resolved by AI</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* --- UNIFIED INBOX --- */}
        {activeTab === 'inbox' && (
            <div className="flex-1 flex bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                {/* Thread List */}
                <div className="w-80 border-r border-slate-800 flex flex-col bg-slate-900">
                    <div className="p-4 border-b border-slate-800">
                        <h2 className="font-bold text-white">Inbox</h2>
                    </div>
                    <div className="flex-1 overflow-y-auto">
                        {INBOX_THREADS.map(t => (
                            <div key={t.id} onClick={() => setSelectedThread(t.id)} className={`p-4 border-b border-slate-800 cursor-pointer hover:bg-slate-800 ${selectedThread === t.id ? 'bg-slate-800 border-l-2 border-l-brand-500' : ''}`}>
                                <div className="flex justify-between mb-1">
                                    <span className="font-medium text-white text-sm">{t.customerName}</span>
                                    <span className="text-xs text-slate-500">{t.timestamp}</span>
                                </div>
                                <p className="text-xs text-slate-400 truncate">{t.lastMessage}</p>
                                <div className="flex gap-2 mt-2">
                                    {t.platform === 'whatsapp' && <MessageCircle className="w-3 h-3 text-green-500" />}
                                    {t.platform === 'sms' && <Phone className="w-3 h-3 text-blue-500" />}
                                    <span className="text-[10px] text-slate-500 uppercase">{t.platform}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                {/* Chat */}
                <div className="flex-1 flex flex-col bg-slate-950/50">
                    <div className="p-4 border-b border-slate-800 flex justify-between items-center">
                        <h3 className="font-bold text-white">Sarah Jenkins</h3>
                        <span className="text-xs text-slate-500">WhatsApp • Online</span>
                    </div>
                    <div className="flex-1 p-4 space-y-4 overflow-y-auto">
                        <div className="flex gap-3">
                            <div className="w-8 h-8 rounded-full bg-slate-700 flex-shrink-0"></div>
                            <div className="bg-slate-800 p-3 rounded-xl rounded-tl-none text-sm text-slate-200 max-w-[70%]">
                                I haven't received my tracking number yet.
                            </div>
                        </div>
                        <div className="flex gap-3 flex-row-reverse">
                            <div className="w-8 h-8 rounded-full bg-brand-600 flex-shrink-0"></div>
                            <div className="bg-brand-600/20 border border-brand-500/30 p-3 rounded-xl rounded-tr-none text-sm text-white max-w-[70%]">
                                Hi Sarah, I'm looking into that right now.
                            </div>
                        </div>
                    </div>
                    <div className="p-4 border-t border-slate-800 bg-slate-900">
                        <div className="flex gap-2">
                            <input 
                                type="text" 
                                value={replyText} 
                                onChange={e => setReplyText(e.target.value)}
                                className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white outline-none" 
                                placeholder="Type a reply..." 
                            />
                            <button className="bg-brand-600 p-2 rounded-lg text-white hover:bg-brand-500"><Send className="w-5 h-5" /></button>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* --- INTENTS --- */}
        {activeTab === 'intents' && (
             <div className="flex-1 overflow-y-auto bg-slate-900 border border-slate-800 rounded-xl">
                <div className="p-4 border-b border-slate-800 flex justify-between items-center sticky top-0 bg-slate-900 z-10">
                    <h3 className="font-bold text-white">Intent Library ({intents.length})</h3>
                    <button className="bg-brand-600 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2">
                        <Plus className="w-4 h-4" /> New Intent
                    </button>
                </div>
                <table className="w-full text-left text-sm text-slate-400">
                    <thead className="bg-slate-950 text-slate-200 uppercase text-xs">
                        <tr>
                            <th className="px-6 py-3">Intent</th>
                            <th className="px-6 py-3">Category</th>
                            <th className="px-6 py-3">Stats</th>
                            <th className="px-6 py-3 text-right">Edit</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                        {intents.map(intent => (
                            <tr key={intent.id} className="hover:bg-slate-800/50">
                                <td className="px-6 py-4">
                                    <p className="text-white font-medium">{intent.name}</p>
                                    <p className="text-xs text-slate-500 truncate max-w-xs">{intent.description}</p>
                                </td>
                                <td className="px-6 py-4">
                                    <span className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-xs capitalize">{intent.category}</span>
                                </td>
                                <td className="px-6 py-4">
                                    <span className="text-emerald-400 text-xs font-bold">{intent.automationRate}% Auto</span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <button onClick={() => setEditingIntent(intent)} className="text-slate-500 hover:text-white"><Edit3 className="w-4 h-4" /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
             </div>
        )}

        {/* --- SIMULATOR --- */}
        {activeTab === 'simulator' && (
            <div className="flex-1 flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                <div className="flex-1 p-6 overflow-y-auto bg-[#0b141a] space-y-4">
                    {simMessages.map(msg => (
                        <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[80%] px-4 py-2 rounded-xl text-sm ${msg.role === 'user' ? 'bg-[#005c4b] text-white' : 'bg-[#202c33] text-slate-200'}`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    {isSimulating && <div className="text-slate-500 text-xs ml-4">Typing...</div>}
                </div>
                <div className="p-4 bg-[#202c33]">
                    <div className="flex gap-2">
                        <input 
                            className="flex-1 bg-[#2a3942] text-white px-4 py-3 rounded-lg outline-none" 
                            placeholder="Test message..."
                            value={simInput}
                            onChange={e => setSimInput(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleSimulate()}
                        />
                        <button onClick={handleSimulate} className="bg-brand-600 p-3 rounded-lg text-white"><Send className="w-5 h-5" /></button>
                    </div>
                </div>
            </div>
        )}
        
        {/* --- PERSONALITY (Placeholder for brevity) --- */}
        {activeTab === 'personality' && (
             <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center">
                 <Smile className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                 <h3 className="text-xl font-bold text-white">Personality Engine</h3>
                 <p className="text-slate-400">Configure tone, emoji usage, and brand voice here.</p>
             </div>
        )}
      </div>

      {/* Edit Modal */}
      {editingIntent && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
              <div className="bg-slate-900 w-full max-w-lg rounded-xl border border-slate-700 p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Edit Intent</h3>
                  <div className="space-y-4">
                      <div>
                          <label className="text-xs text-slate-400">Triggers</label>
                          <textarea className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white h-24" value={editingIntent.triggers.join(', ')} onChange={() => {}} />
                      </div>
                      <div>
                          <label className="text-xs text-slate-400">Response</label>
                          <textarea className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-white h-32" value={editingIntent.responseTemplate} onChange={() => {}} />
                      </div>
                      <button onClick={handleAiRewrite} className="w-full bg-purple-600/20 text-purple-400 py-2 rounded border border-purple-500/50 flex items-center justify-center gap-2 hover:bg-purple-600/30">
                          <Sparkles className="w-4 h-4" /> Rewrite with AI
                      </button>
                      <div className="flex gap-2">
                          <button onClick={() => setEditingIntent(null)} className="flex-1 py-2 bg-slate-800 text-white rounded">Cancel</button>
                          <button onClick={() => setEditingIntent(null)} className="flex-1 py-2 bg-brand-600 text-white rounded">Save</button>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

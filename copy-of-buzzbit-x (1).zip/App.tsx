
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './pages/Dashboard';
import { Campaigns } from './pages/Campaigns';
import { Inbox } from './pages/Inbox';
import { BusinessHub } from './pages/BusinessHub'; // Merged page
import { AIPlanner } from './pages/AIPlanner';
import { Social } from './pages/Social';
import { Popups } from './pages/Popups';
import { EmailBuilder } from './pages/EmailBuilder';
import { Landing } from './pages/Landing';
import { Auth } from './pages/Auth';
import { UnifiedAgent } from './pages/UnifiedAgent';
import { Integrations } from './pages/Integrations';
import { Settings } from './pages/Settings';
import { AICopilot } from './components/AICopilot';

const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth >= 768);
  const location = useLocation();

  useEffect(() => {
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  }, [location]);

  return (
    <div className="flex h-screen bg-slate-950 text-white overflow-hidden">
      <Sidebar isOpen={sidebarOpen} toggle={() => setSidebarOpen(!sidebarOpen)} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <Header toggleSidebar={() => setSidebarOpen(!sidebarOpen)} />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 scroll-smooth bg-slate-950 relative w-full">
          {children}
        </main>
        <AICopilot />
      </div>
    </div>
  );
};

const AppRoutes = () => {
  const location = useLocation();
  const isPublic = location.pathname === '/landing' || location.pathname === '/auth';

  if (isPublic) {
    return (
      <Routes>
        <Route path="/landing" element={<Landing />} />
        <Route path="/auth" element={<Auth />} />
      </Routes>
    );
  }

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/landing" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/agent" element={<UnifiedAgent />} />
        <Route path="/inbox" element={<Inbox />} />
        <Route path="/campaigns" element={<Campaigns />} />
        <Route path="/email-builder" element={<EmailBuilder />} />
        <Route path="/social" element={<Social />} />
        <Route path="/popups" element={<Popups />} />
        <Route path="/business" element={<BusinessHub />} />
        <Route path="/ai-planner" element={<AIPlanner />} />
        <Route path="/integrations" element={<Integrations />} />
        <Route path="/settings" element={<Settings />} />
        {/* Legacy redirects */}
        <Route path="/customers" element={<Navigate to="/business" replace />} />
        <Route path="/commerce" element={<Navigate to="/business" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AppLayout>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <AppRoutes />
    </HashRouter>
  );
};

export default App;
